// Authentication handler for the exit gate system

// API base URL - simplified to always use relative path
const API_URL = '/api';

// Notification function
function showNotification(title, message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} notification`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        max-width: 500px;
        animation: slideIn 0.5s ease-out;
    `;
    
    notification.innerHTML = `
        <strong>${title}</strong><br>
        <span>${message}</span>
    `;
    
    // Add to document
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.5s ease-in';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 450);
    }, 3000);
}

// Global auth state for other scripts to use
window.authState = {
    token: localStorage.getItem('exitGateAuthToken'),
    user: null
};

// DOM elements
const loginForm = document.getElementById('login-form');
const loginSection = document.getElementById('login-section');
const appSection = document.getElementById('app-section');
const userInfo = document.getElementById('user-info');
const userNameElement = document.getElementById('user-name');
const userRoleElement = document.getElementById('user-role');
const logoutBtn = document.getElementById('logout-btn');

// Check if user is already logged in
function checkAuthState() {
    if (window.authState.token) {
        // Fetch current user info
        fetchCurrentUser();
    } else {
        // Show login form
        showLoginForm();
    }
}

// Show login form
function showLoginForm() {
    loginSection.style.display = 'flex';
    appSection.style.display = 'none';
    userInfo.style.display = 'none';
}

// Show app after successful login
function showApp() {
    loginSection.style.display = 'none';
    appSection.style.display = 'block';
    userInfo.style.display = 'block';

    // Display user info
    if (window.authState.user) {
        userNameElement.textContent = window.authState.user.name || window.authState.user.email;
        userRoleElement.textContent = window.authState.user.role;
    }
}

// Login handler
async function handleLogin(email, password) {
    try {
        console.log('Attempting login with:', { email });
        
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();
        console.log('Login response:', data);

        if (!response.ok) {
            throw new Error(data.message || 'Login failed');
        }

        // Save token and user info
        window.authState.token = data.token;
        window.authState.user = data.user;

        // Save token to localStorage
        localStorage.setItem('exitGateAuthToken', data.token);
        
        // Show success message
        showNotification('Login Successful', 'Welcome back!', 'success');
        
        // Show the app
        showApp();
        
        return true;
    } catch (error) {
        console.error('Login error:', error);
        showNotification('Login Failed', error.message, 'error');
        return false;
    }
}

// Get current user info
async function fetchCurrentUser() {
    try {
        console.log('Fetching user info...');
        
        const response = await fetch(`${API_URL}/auth/me`, {
            headers: {
                'Authorization': `Bearer ${window.authState.token}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to get user info');
        }

        const data = await response.json();
        console.log('User data:', data);
        
        // Save user info
        window.authState.user = data.user;
        
        // Show the app
        showApp();
    } catch (error) {
        console.error('Get user error:', error);
        // If there's an error, show login form
        handleLogout();
    }
}

// Logout handler
function handleLogout() {
    // Clear auth data
    localStorage.removeItem('exitGateAuthToken');
    window.authState.token = null;
    window.authState.user = null;
    
    // Show login form
    showLoginForm();
    
    // Show logout message
    showNotification('Logged Out', 'You have been logged out successfully.', 'info');
}

// Event Listeners
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    await handleLogin(email, password);
});

logoutBtn.addEventListener('click', () => {
    handleLogout();
});

// Initialize auth state
document.addEventListener('DOMContentLoaded', () => {
    checkAuthState();
}); 