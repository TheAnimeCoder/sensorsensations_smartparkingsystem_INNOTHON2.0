// Main application logic for Exit Gate

// DOM elements
const startScannerBtn = document.getElementById('start-scanner');
const stopScannerBtn = document.getElementById('stop-scanner');
const resultContainer = document.getElementById('result-container');
const recentExitsContainer = document.getElementById('recent-exits-container');
const manualExitForm = document.getElementById('manual-exit-form');

// QR Scanner instance
let html5QrCodeScanner = null;

// Start QR scanner
function startScanner() {
    const html5QrCode = new Html5Qrcode("reader");
    
    // Enhanced QR scanner configuration for better detection
    const config = { 
        fps: 15,  // Increased frame rate
        qrbox: { width: 300, height: 300 },  // Larger scanning area
        aspectRatio: 1.0,
        formatsToSupport: [0], // 0 is for QR_CODE format
        experimentalFeatures: {
            useBarCodeDetectorIfSupported: true
        }
    };
    
    // Try to get available cameras
    Html5Qrcode.getCameras()
        .then(cameras => {
            console.log("Available cameras:", cameras);
            
            // Try to use back camera first (better for QR scanning)
            let cameraId = cameras[0].id;
            const backCamera = cameras.find(camera => 
                camera.label.toLowerCase().includes('back') || 
                camera.label.toLowerCase().includes('rear')
            );
            
            if (backCamera) {
                cameraId = backCamera.id;
                console.log('Using back camera:', backCamera.label);
            }
            
            // Start scanner with selected camera
            return html5QrCode.start(
                { deviceId: cameraId },
                config,
                onScanSuccess,
                onScanError
            );
        })
        .then(() => {
            html5QrCodeScanner = html5QrCode;
            startScannerBtn.style.display = 'none';
            stopScannerBtn.style.display = 'block';
            
            // Show scanning indicator
            resultContainer.innerHTML = `
                <div class="alert alert-info">
                    <p>Scanner active. Point camera at a QR code.</p>
                </div>
            `;
        })
        .catch(err => {
            console.error("Error starting scanner:", err);
            
            // Fallback to environment facing camera if specific camera selection fails
            html5QrCode.start(
                { facingMode: "environment" }, 
                config,
                onScanSuccess,
                onScanError
            )
            .then(() => {
                html5QrCodeScanner = html5QrCode;
                startScannerBtn.style.display = 'none';
                stopScannerBtn.style.display = 'block';
                
                // Show scanning indicator
                resultContainer.innerHTML = `
                    <div class="alert alert-info">
                        <p>Scanner active. Point camera at a QR code.</p>
                    </div>
                `;
            })
            .catch(startErr => {
                console.error("Failed to start scanner:", startErr);
                alert(`Could not start scanner: ${startErr.message || startErr}`);
            });
        });
}

// Stop QR scanner
function stopScanner() {
    if (html5QrCodeScanner) {
        html5QrCodeScanner.stop()
            .then(() => {
                html5QrCodeScanner = null;
                startScannerBtn.style.display = 'block';
                stopScannerBtn.style.display = 'none';
            })
            .catch(err => {
                console.error("Error stopping scanner:", err);
            });
    }
}

// Handle successful QR scan
function onScanSuccess(decodedText, decodedResult) {
    console.log("QR Code scanned successfully:", decodedText);
    
    // Play beep sound to indicate successful scan
    const beep = new Audio('data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU...');
    beep.play();

    // Process the scanned QR code
    processQRCode(decodedText);
    
    // Stop scanner after successful scan
    stopScanner();
}

// Handle QR scan error
function onScanError(err) {
    // Not displaying errors as they happen constantly during scanning
    // console.error(`QR Scan Error: ${err}`);
}

// Process the QR code data
async function processQRCode(qrData) {
    // Show loading in result container
    resultContainer.innerHTML = `
        <div class="alert alert-info">
            <div class="d-flex justify-content-center align-items-center">
                <div class="loading me-2"></div>
                <span>Processing QR code...</span>
            </div>
        </div>
    `;
    
    try {
        // Check if QR data is valid
        let parsedData;
        try {
            parsedData = JSON.parse(qrData);
            console.log("Parsed QR data:", parsedData);
        } catch (error) {
            console.error("QR parsing error:", error);
            throw new Error("Invalid QR code format. Please scan a valid parking QR code.");
        }
        
        // Debug logging for authentication
        console.log('Processing QR with token:', authToken);
        
        // Make API call to process the QR code for exit
        const response = await fetch(`${API_URL}/parking/process-qr`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ 
                qrData,
                exitGate: 'EXIT1' // Can be dynamically set based on config
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || "Failed to process exit");
        }
        
        // Display success message
        displayExitSuccess(data.data);
        
        // Refresh recent exits list
        loadRecentExits();
    } catch (error) {
        // Display error
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                <strong>Error:</strong> ${error.message}
                <button class="btn btn-sm btn-primary float-end mt-2" onclick="startScanner()">
                    Scan Again
                </button>
            </div>
        `;
    }
}

// Process manual vehicle exit
async function processManualExit(vehicleNumber) {
    // Show loading in result container
    resultContainer.innerHTML = `
        <div class="alert alert-info">
            <div class="d-flex justify-content-center align-items-center">
                <div class="loading me-2"></div>
                <span>Processing vehicle exit...</span>
            </div>
        </div>
    `;
    
    try {
        // Create a mock QR data with the vehicle number
        const mockQrData = JSON.stringify({
            vehicleNumber: vehicleNumber,
            driverName: "Manual Entry",
            contactNumber: ""
        });
        
        // Debug logging for authentication
        console.log('Processing manual exit with token:', authToken);
        
        // Make API call to process the exit
        const response = await fetch(`${API_URL}/parking/process-qr`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({ 
                qrData: mockQrData,
                exitGate: 'EXIT1'
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.message || "Failed to process exit");
        }
        
        // Display success message
        displayExitSuccess(data.data);
        
        // Refresh recent exits list
        loadRecentExits();
    } catch (error) {
        // Display error
        resultContainer.innerHTML = `
            <div class="alert alert-danger">
                <strong>Error:</strong> ${error.message}
            </div>
        `;
    }
}

// Display successful exit information
function displayExitSuccess(exitData) {
    // Format dates
    const entryTime = new Date(exitData.entryTime).toLocaleString();
    const exitTime = new Date(exitData.exitTime).toLocaleString();
    
    // Calculate parking duration
    const durationMs = new Date(exitData.exitTime) - new Date(exitData.entryTime);
    const hours = Math.floor(durationMs / (1000 * 60 * 60));
    const minutes = Math.floor((durationMs % (1000 * 60 * 60)) / (1000 * 60));
    const duration = `${hours}h ${minutes}m`;
    
    resultContainer.innerHTML = `
        <div class="alert alert-success">
            <h4 class="alert-heading">Exit Successful!</h4>
            <p>Vehicle has been marked as exited from the parking lot.</p>
            <hr>
            <div class="exit-details">
                <div><strong>Vehicle Number:</strong> ${exitData.vehicleNumber}</div>
                <div><strong>Driver:</strong> ${exitData.driverName}</div>
                <div><strong>Entry Time:</strong> ${entryTime}</div>
                <div><strong>Exit Time:</strong> ${exitTime}</div>
                <div><strong>Duration:</strong> ${duration}</div>
                <div><strong>Entry Gate:</strong> ${exitData.entryGate}</div>
                <div><strong>Exit Gate:</strong> ${exitData.exitGate || 'EXIT1'}</div>
            </div>
            <hr>
            <button class="btn btn-primary" onclick="startScanner()">
                Scan Next
            </button>
        </div>
    `;
}

// Load recent exits
async function loadRecentExits() {
    if (!authToken) return;
    
    try {
        const response = await fetch(`${API_URL}/parking/recent-exits?limit=5`, {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });
        
        if (!response.ok) {
            throw new Error("Failed to load recent exits");
        }
        
        const data = await response.json();
        
        if (data.data.length === 0) {
            recentExitsContainer.innerHTML = `<p class="text-center">No recent exits found</p>`;
            return;
        }
        
        // Display recent exits
        recentExitsContainer.innerHTML = `
            <div class="list-group">
                ${data.data.map(exit => {
                    const exitTime = new Date(exit.exitTime).toLocaleString();
                    return `
                        <div class="list-group-item recent-exit-item">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">${exit.vehicleNumber}</h6>
                                <small>${exitTime}</small>
                            </div>
                            <p class="mb-1">${exit.driverName}</p>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    } catch (error) {
        console.error("Error loading recent exits:", error);
        recentExitsContainer.innerHTML = `
            <div class="alert alert-danger">
                Failed to load recent exits: ${error.message}
            </div>
        `;
    }
}

// Event listeners
startScannerBtn.addEventListener('click', startScanner);
stopScannerBtn.addEventListener('click', stopScanner);

// Manual exit form handler
manualExitForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const vehicleNumber = document.getElementById('vehicleNumber').value;
    if (vehicleNumber) {
        processManualExit(vehicleNumber);
        // Clear the form
        document.getElementById('vehicleNumber').value = '';
    }
});

// Function to load recent exits (reference for auth.js)
window.loadRecentExits = loadRecentExits;