const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Mock users for development/testing
const MOCK_USERS = [
  { _id: 'user1', email: 'admin@example.com', role: 'admin' },
  { _id: 'user2', email: 'operator@example.com', role: 'operator' }
];

// Check if we're using mock database
const isMockDB = () => {
  return process.env.MOCK_DB === 'true' || global.MOCK_DB === true;
};

// Verify JWT token and attach user to request
exports.auth = async (req, res, next) => {
  try {
    // Get token from header
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'No authentication token, access denied'
      });
    }

    // Using mock database
    if (isMockDB()) {
      // For mock mode, we'll use a simplified token verification
      // In real implementation, this would verify the JWT properly
      if (token === 'mock-admin-token') {
        req.user = MOCK_USERS[0];
        return next();
      } else if (token === 'mock-operator-token') {
        req.user = MOCK_USERS[1];
        return next();
      } else {
        return res.status(401).json({
          success: false,
          message: 'Invalid token'
        });
      }
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    
    // Find user by id
    const user = await User.findById(decoded.id);
    
    if (!user || !user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'User not found or inactive'
      });
    }
    
    // Attach user to request
    req.user = user;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.status(401).json({
      success: false, 
      message: 'Token is not valid'
    });
  }
};

// Middleware to check if user is admin
exports.isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    return next();
  }
  
  return res.status(403).json({
    success: false,
    message: 'Access denied. Admin privileges required.'
  });
}; 