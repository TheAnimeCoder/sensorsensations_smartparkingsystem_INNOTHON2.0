const mongoose = require('mongoose');

const parkingEntrySchema = new mongoose.Schema({
  vehicleNumber: {
    type: String,
    required: true,
    trim: true
  },
  driverName: {
    type: String,
    required: true,
    trim: true
  },
  contactNumber: {
    type: String,
    required: false,
    trim: true
  },
  entryTime: {
    type: Date,
    default: Date.now
  },
  exitTime: {
    type: Date,
    default: null
  },
  isActive: {
    type: Boolean,
    default: true
  },
  qrData: {
    type: String,
    required: true
  },
  entryGate: {
    type: String,
    required: true,
    enum: ['GATE1', 'GATE2', 'GATE3', 'OTHER']
  },
  exitGate: {
    type: String,
    enum: ['EXIT1', 'EXIT2', 'EXIT3', 'OTHER'],
    default: null
  },
  scanOperator: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  }
}, {
  timestamps: true
});

const ParkingEntry = mongoose.model('ParkingEntry', parkingEntrySchema);

module.exports = ParkingEntry; 