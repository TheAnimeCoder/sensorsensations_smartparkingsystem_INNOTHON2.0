const ParkingEntry = require('../models/ParkingEntry');

// Mock data for development/testing when no DB is available
let MOCK_ENTRIES = [
  {
    _id: '1',
    vehicleNumber: 'ABC123',
    driverName: 'John Doe',
    contactNumber: '1234567890',
    entryTime: new Date(Date.now() - 3600000), // 1 hour ago
    entryGate: 'ENTRY1',
    isActive: true,
    scanOperator: 'op1',
    createdAt: new Date(Date.now() - 3600000),
    updatedAt: new Date(Date.now() - 3600000)
  },
  {
    _id: '2',
    vehicleNumber: 'XYZ789',
    driverName: 'Jane Smith',
    contactNumber: '9876543210',
    entryTime: new Date(Date.now() - 7200000), // 2 hours ago
    entryGate: 'ENTRY2',
    isActive: true,
    scanOperator: 'op1',
    createdAt: new Date(Date.now() - 7200000),
    updatedAt: new Date(Date.now() - 7200000)
  }
];

// Calculate parking fee based on duration
const calculateParkingFee = (entryTime, exitTime) => {
  const durationMs = exitTime.getTime() - entryTime.getTime();
  const durationHours = Math.ceil(durationMs / (1000 * 60 * 60));
  
  // Base fee for first 2 hours
  let fee = 50;
  
  // Additional fee per hour after first 2 hours
  if (durationHours > 2) {
    fee += (durationHours - 2) * 20;
  }
  
  return fee;
};

// Check if we're using mock database
const isMockDB = () => {
  return process.env.MOCK_DB === 'true' || global.MOCK_DB === true;
};

// Process QR code scan for exit gate
exports.processQRCode = async (req, res) => {
  try {
    const { qrData, exitGate } = req.body;
    const scanOperator = req.user._id;

    // Enhance logging for troubleshooting
    console.log('Received QR data:', qrData);
    console.log('Request body:', req.body);

    if (!qrData) {
      return res.status(400).json({
        success: false,
        message: 'QR code data is required'
      });
    }

    // Attempt to parse the QR data with improved handling
    let parsedData;
    try {
      // Handle multiple levels of string encoding
      if (typeof qrData === 'string') {
        try {
          // First try direct parsing
          parsedData = JSON.parse(qrData);
        } catch (e) {
          console.log('First parsing attempt failed, trying alternative approaches');
          
          // Check if it's doubly stringified JSON
          try {
            // Remove outer quotes and unescape inner quotes if needed
            const unwrappedData = qrData.replace(/^"|"$/g, '').replace(/\\"/g, '"');
            parsedData = JSON.parse(unwrappedData);
          } catch (e2) {
            console.log('Second parsing attempt failed:', e2);
            
            // If all parsing fails, create a simple object with the data
            // This allows manual processing of non-standard formats
            if (qrData.includes('vehicleNumber')) {
              // Try to extract vehicle number using regex
              const vehicleMatch = qrData.match(/vehicleNumber["\s:]+([^"',}\s]+)/);
              if (vehicleMatch && vehicleMatch[1]) {
                parsedData = { vehicleNumber: vehicleMatch[1] };
              } else {
                throw new Error('Could not extract vehicle number from QR data');
              }
            } else {
              // Assume the QR data is directly the vehicle number as a fallback
              parsedData = { vehicleNumber: qrData };
            }
          }
        }
      } else if (typeof qrData === 'object') {
        // If already an object, use it directly
        parsedData = qrData;
      } else {
        throw new Error('Invalid QR code data type');
      }
      
      // Log parsed data for debugging
      console.log('Successfully parsed QR data:', parsedData);
      
      // Ensure we have the required data
      if (!parsedData.vehicleNumber) {
        return res.status(400).json({
          success: false,
          message: 'Invalid QR code data. Vehicle number is required.'
        });
      }
    } catch (error) {
      console.error('QR data parsing error:', error);
      return res.status(400).json({
        success: false,
        message: 'Invalid QR code format. QR code should contain valid vehicle data.'
      });
    }

    // Extract vehicle information from parsed data
    const { vehicleNumber } = parsedData;
    console.log('Processing exit for vehicle:', vehicleNumber);

    // Mock DB handling
    if (isMockDB()) {
      console.log('Processing in mock mode for vehicle:', vehicleNumber);
      
      // Check if vehicle exists and is active in mock entries
      const existingEntryIndex = MOCK_ENTRIES.findIndex(entry => 
        entry.vehicleNumber === vehicleNumber && entry.isActive === true
      );

      if (existingEntryIndex === -1) {
        return res.status(404).json({
          success: false,
          message: `Vehicle ${vehicleNumber} not found in parking lot. It may have already exited or was not properly registered at entry.`
        });
      }

      // Record exit in mock database
      const exitTime = new Date();
      const parkingFee = calculateParkingFee(MOCK_ENTRIES[existingEntryIndex].entryTime, exitTime);
      
      const updatedEntry = {
        ...MOCK_ENTRIES[existingEntryIndex],
        exitTime: exitTime,
        isActive: false,
        exitGate: exitGate || 'EXIT1',
        parkingFee: parkingFee,
        updatedAt: exitTime
      };
      
      // Update the mock entry
      MOCK_ENTRIES[existingEntryIndex] = updatedEntry;
      
      console.log('Exit recorded in mock mode:', updatedEntry);

      return res.status(200).json({
        success: true,
        message: 'Vehicle exit recorded successfully',
        data: updatedEntry
      });
    }

    // Regular DB mode
    console.log('Processing in DB mode for vehicle:', vehicleNumber);
    
    // Find the active entry for this vehicle
    const existingEntry = await ParkingEntry.findOne({
      vehicleNumber,
      isActive: true
    });

    if (!existingEntry) {
      return res.status(404).json({
        success: false,
        message: `Vehicle ${vehicleNumber} not found in parking lot. It may have already exited or was not properly registered at entry.`
      });
    }

    // Record exit
    const exitTime = new Date();
    const parkingFee = calculateParkingFee(existingEntry.entryTime, exitTime);
    
    existingEntry.exitTime = exitTime;
    existingEntry.isActive = false;
    existingEntry.exitGate = exitGate || 'EXIT1';
    existingEntry.parkingFee = parkingFee;
    
    const updatedEntry = await existingEntry.save();
    console.log('Exit recorded in DB:', updatedEntry);

    res.status(200).json({
      success: true,
      message: 'Vehicle exit recorded successfully',
      data: updatedEntry
    });
  } catch (error) {
    console.error('QR scan processing error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while processing QR code',
      error: error.message
    });
  }
};

// Get all active parking entries
exports.getActiveEntries = async (req, res) => {
  try {
    if (isMockDB()) {
      // Filter active entries for mock mode
      const activeEntries = MOCK_ENTRIES.filter(entry => entry.isActive === true);
      
      return res.status(200).json({
        success: true,
        count: activeEntries.length,
        data: activeEntries
      });
    }

    const entries = await ParkingEntry.find({ isActive: true })
      .sort({ entryTime: -1 })
      .populate('scanOperator', 'name email');

    res.status(200).json({
      success: true,
      count: entries.length,
      data: entries
    });
  } catch (error) {
    console.error('Get entries error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Get entry by vehicle number
exports.getEntryByVehicleNumber = async (req, res) => {
  try {
    const { vehicleNumber } = req.params;

    if (isMockDB()) {
      // Find active entry with this vehicle number
      const entry = MOCK_ENTRIES.find(
        entry => entry.vehicleNumber === vehicleNumber && entry.isActive === true
      );
      
      if (!entry) {
        return res.status(404).json({
          success: false,
          message: 'No active entry found for this vehicle'
        });
      }

      return res.status(200).json({
        success: true,
        data: entry
      });
    }

    const entry = await ParkingEntry.findOne({
      vehicleNumber,
      isActive: true
    }).populate('scanOperator', 'name email');

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'No active entry found for this vehicle'
      });
    }

    res.status(200).json({
      success: true,
      data: entry
    });
  } catch (error) {
    console.error('Get by vehicle number error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Get recent exits
exports.getRecentExits = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    
    if (isMockDB()) {
      // Get recent exits (non-active entries with exitTime)
      const recentExits = MOCK_ENTRIES
        .filter(entry => !entry.isActive && entry.exitTime)
        .sort((a, b) => new Date(b.exitTime) - new Date(a.exitTime))
        .slice(0, limit);
      
      return res.status(200).json({
        success: true,
        count: recentExits.length,
        data: recentExits
      });
    }

    const exits = await ParkingEntry.find({ 
      isActive: false,
      exitTime: { $ne: null }
    })
    .sort({ exitTime: -1 })
    .limit(limit)
    .populate('scanOperator', 'name email');

    res.status(200).json({
      success: true,
      count: exits.length,
      data: exits
    });
  } catch (error) {
    console.error('Get recent exits error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
}; 