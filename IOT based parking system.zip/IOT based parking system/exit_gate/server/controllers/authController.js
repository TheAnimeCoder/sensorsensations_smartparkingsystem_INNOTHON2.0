const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Mock data for development/testing
const MOCK_USERS = [
  {
    _id: 'user1',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    isActive: true,
    password: 'admin123' // In a real system, this would be hashed
  },
  {
    _id: 'user2',
    name: 'Operator User',
    email: 'operator@example.com',
    role: 'operator',
    isActive: true,
    password: 'operator123' // In a real system, this would be hashed
  }
];

// Check if we're using mock database
const isMockDB = () => {
  return process.env.MOCK_DB === 'true' || global.MOCK_DB === true;
};

// Login user
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password'
      });
    }

    // Using mock database
    if (isMockDB()) {
      const user = MOCK_USERS.find(u => u.email === email);
      
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials'
        });
      }

      // Simple password check for mock mode
      if (user.password !== password) {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials'
        });
      }

      // Create token
      const token = user.role === 'admin' ? 'mock-admin-token' : 'mock-operator-token';

      // Remove password from response
      const { password: _, ...userWithoutPassword } = user;

      return res.status(200).json({
        success: true,
        message: 'Login successful (mock mode)',
        token,
        user: userWithoutPassword
      });
    }

    // Find user by email
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'Account is inactive. Please contact administrator.'
      });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Create token
    const token = jwt.sign(
      { id: user._id },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '1d' }
    );

    // Update last login
    user.lastLogin = new Date();
    await user.save();

    // Remove password from response
    const userObj = user.toObject();
    delete userObj.password;

    res.status(200).json({
      success: true,
      message: 'Login successful',
      token,
      user: userObj
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during login',
      error: error.message
    });
  }
};

// Get current user details
exports.getCurrentUser = async (req, res) => {
  try {
    // User is attached to request in auth middleware
    const user = req.user;

    // Using mock database
    if (isMockDB()) {
      // Return user without password
      const { password: _, ...userWithoutPassword } = user;
      
      return res.status(200).json({
        success: true,
        user: userWithoutPassword
      });
    }

    // Find user in DB to get fresh data
    const currentUser = await User.findById(user._id).select('-password');
    
    if (!currentUser) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      user: currentUser
    });
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
}; 