/**
 * Authentication functionality for the QR code scanner application
 */

// API Base URL
const API_BASE_URL = '/api';

// Auth state object
const authState = {
    isAuthenticated: false,
    token: null,
    user: null,
};

// DOM Elements
const loginForm = document.getElementById('login-form');
const loginSection = document.getElementById('login-section');
const scannerSection = document.getElementById('scanner-section');
const userInfoElement = document.getElementById('user-info');
const logoutButton = document.getElementById('logout-btn');

// Check if user is already logged in (token in local storage)
function checkAuthState() {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (token && userData) {
        try {
            // Parse user data from storage
            const user = JSON.parse(userData);
            
            // Update auth state
            authState.isAuthenticated = true;
            authState.token = token;
            authState.user = user;
            
            // Verify token validity and refresh if needed
            verifyAndRefreshToken();
            
            // Show scanner section
            showScannerUI();
            
            // Fetch active entries
            if (typeof fetchActiveEntries === 'function') {
                fetchActiveEntries();
            }
            
            return true;
        } catch (error) {
            console.error('Failed to parse user data:', error);
            logout();
        }
    }
    
    return false;
}

// Verify token validity and refresh if needed
async function verifyAndRefreshToken() {
    try {
        // Check token validity by making a request to the server
        const response = await fetch(`${API_BASE_URL}/auth/verify-token`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${authState.token}`
            }
        });
        
        // If token is invalid or expired, try to refresh
        if (!response.ok) {
            console.log('Token invalid or expired, attempting refresh...');
            await refreshToken();
        }
    } catch (error) {
        console.error('Token verification error:', error);
        // If verification fails completely, log out
        logout();
    }
}

// Refresh the authentication token
async function refreshToken() {
    try {
        // Only try to refresh if we have a user
        if (!authState.user || !authState.user.email) {
            throw new Error('No user data for token refresh');
        }
        
        // Make a request to refresh the token
        const response = await fetch(`${API_BASE_URL}/auth/refresh-token`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: authState.user.email,
                refreshToken: localStorage.getItem('refreshToken') // Optional, depends on implementation
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to refresh token');
        }
        
        const data = await response.json();
        
        // Get new token
        const token = data.data ? data.data.token : data.token;
        
        if (!token) {
            throw new Error('No token received from server');
        }
        
        // Update token in storage and auth state
        localStorage.setItem('token', token);
        authState.token = token;
        
        // If there's a new refresh token, save it too
        if (data.refreshToken) {
            localStorage.setItem('refreshToken', data.refreshToken);
        }
        
        console.log('Token refreshed successfully');
        return true;
    } catch (error) {
        console.error('Token refresh error:', error);
        // If refresh fails, log out
        logout();
        return false;
    }
}

// Make refreshToken function globally available
window.refreshToken = refreshToken;

// Show scanner UI
function showScannerUI() {
    loginSection.classList.add('d-none');
    scannerSection.classList.remove('d-none');
    
    // Update user info display
    if (authState.user) {
        userInfoElement.textContent = `${authState.user.name} (${authState.user.role})`;
    }
}

// Show login UI
function showLoginUI() {
    scannerSection.classList.add('d-none');
    loginSection.classList.remove('d-none');
}

// Login function
async function login(email, password) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });
        
        const data = await response.json();
        
        // Debug the response structure
        console.log('Login response:', data);
        
        if (!response.ok) {
            throw new Error(data.message || 'Login failed');
        }
        
        // Get token and user from the correct response structure
        const token = data.data ? data.data.token : data.token;
        const user = data.data ? data.data.user : data.user;
        
        if (!token) {
            throw new Error('No token received from server');
        }
        
        // Save token and user data to local storage
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        
        // Save refresh token if available
        if (data.refreshToken || (data.data && data.data.refreshToken)) {
            const refreshToken = data.data ? data.data.refreshToken : data.refreshToken;
            localStorage.setItem('refreshToken', refreshToken);
        }
        
        // Update auth state
        authState.isAuthenticated = true;
        authState.token = token;
        authState.user = user;
        
        // Show scanner section
        showScannerUI();
        
        // Fetch active entries
        if (typeof fetchActiveEntries === 'function') {
            fetchActiveEntries();
        }
        
        // Show success notification
        showNotification('Login Successful', 'You have successfully logged in.', 'success');
        
        return true;
    } catch (error) {
        console.error('Login error:', error);
        showNotification('Login Failed', error.message, 'error');
        return false;
    }
}

// Logout function
function logout() {
    // Clear local storage
    localStorage.removeItem('token');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('user');
    
    // Reset auth state
    authState.isAuthenticated = false;
    authState.token = null;
    authState.user = null;
    
    // Show login section
    showLoginUI();
    
    // Show notification
    showNotification('Logged Out', 'You have been logged out successfully.', 'info');
}

// Make logout function globally available
window.logout = logout;

// Handle login form submission
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        await login(email, password);
    });
}

// Handle logout button click
if (logoutButton) {
    logoutButton.addEventListener('click', () => {
        logout();
    });
}

// Initialize authentication state on page load
document.addEventListener('DOMContentLoaded', () => {
    checkAuthState();
}); 