/**
 * Main application file for the Parking QR Scanner system
 */

// Initialize Bootstrap components
let toastElement = null;

// Show notifications
function showNotification(title, message, type = 'info') {
    // Get the toast element
    const toastContainer = document.getElementById('notification-toast');
    
    if (!toastContainer) {
        console.error('Toast container not found');
        return;
    }
    
    // If we don't have a Bootstrap toast instance, create one
    if (!toastElement) {
        toastElement = new bootstrap.Toast(toastContainer, {
            autohide: true,
            delay: 5000
        });
    }
    
    // Set toast title and message
    const toastTitle = document.getElementById('toast-title');
    const toastMessage = document.getElementById('toast-message');
    
    if (toastTitle) {
        toastTitle.textContent = title;
    }
    
    if (toastMessage) {
        toastMessage.textContent = message;
    }
    
    // Set toast color based on type
    toastContainer.className = 'toast';
    
    if (type === 'success') {
        toastContainer.classList.add('bg-success', 'text-white');
    } else if (type === 'error') {
        toastContainer.classList.add('bg-danger', 'text-white');
    } else if (type === 'warning') {
        toastContainer.classList.add('bg-warning', 'text-dark');
    } else {
        toastContainer.classList.add('bg-info', 'text-white');
    }
    
    // Show the toast
    toastElement.show();
}

// Generate a test QR code (for development/testing)
function generateTestQRCode() {
    const testData = {
        vehicleNumber: 'AB123CD',
        driverName: 'John Doe',
        contactNumber: '1234567890'
    };
    
    console.log('Test QR Code Data:');
    console.log(JSON.stringify(testData));
    
    // This data can be used with online QR code generators for testing
    return JSON.stringify(testData);
}

// Initialize the application
function initApp() {
    console.log('Parking QR Scanner App Initialized');
    
    // Disable the stop camera button initially
    if (document.getElementById('stop-camera')) {
        document.getElementById('stop-camera').disabled = true;
    }
    
    // Add demo/development code if needed
    if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') {
        // For development only
        console.log('Development mode detected');
        // generateTestQRCode();
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initApp); 