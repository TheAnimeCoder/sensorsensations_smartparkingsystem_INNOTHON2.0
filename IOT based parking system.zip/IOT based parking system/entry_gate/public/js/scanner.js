/**
 * QR code scanner functionality for the parking entry system
 */

// Global variables
let html5QrCode = null;
let isScanning = false;

// DOM elements
const startCameraButton = document.getElementById('start-camera');
const stopCameraButton = document.getElementById('stop-camera');
const scanResultElement = document.getElementById('scan-result');
const entriesTable = document.getElementById('entries-table');
const entryGateSelect = document.getElementById('entry-gate');

// QR Code scanner configuration
const qrConfig = {
    fps: 15,
    qrbox: { width: 300, height: 300 },
    aspectRatio: 1.0,
    formatsToSupport: [0], // 0 is for QR_CODE format
    experimentalFeatures: {
        useBarCodeDetectorIfSupported: true
    }
};

// Initialize the QR scanner
function initScanner() {
    if (html5QrCode !== null) {
        return;
    }
    
    html5QrCode = new Html5Qrcode("reader");
    
    // Add event listeners
    if (startCameraButton) {
        startCameraButton.addEventListener('click', startScanner);
    }
    
    if (stopCameraButton) {
        stopCameraButton.addEventListener('click', stopScanner);
    }
}

// Start the scanner
async function startScanner() {
    if (isScanning) {
        return;
    }
    
    try {
        // Get camera devices
        const devices = await Html5Qrcode.getCameras();
        console.log('Available cameras:', devices);
        
        if (devices && devices.length) {
            // Try to use back camera first (more suitable for QR scanning)
            let cameraId = devices[0].id;
            
            // Look for back camera
            const backCamera = devices.find(camera => 
                camera.label.toLowerCase().includes('back') || 
                camera.label.toLowerCase().includes('rear')
            );
            
            if (backCamera) {
                cameraId = backCamera.id;
                console.log('Using back camera:', backCamera.label);
            }
            
            // Clear previous scan results
            scanResultElement.innerHTML = `
                <div class="alert alert-info">
                    <p>Scanner active. Point camera at a QR code.</p>
                </div>
            `;
            
            // Start the scanner with selected camera
            await html5QrCode.start(
                { deviceId: cameraId },
                qrConfig,
                onScanSuccess,
                onScanFailure
            );
            
            isScanning = true;
            startCameraButton.disabled = true;
            stopCameraButton.disabled = false;
            
            showNotification('Scanner Started', 'QR code scanner is now active.', 'info');
        } else {
            // Fallback to any available camera
            await html5QrCode.start(
                { facingMode: "environment" },
                qrConfig,
                onScanSuccess,
                onScanFailure
            );
            
            isScanning = true;
            startCameraButton.disabled = true;
            stopCameraButton.disabled = false;
            
            showNotification('Scanner Started', 'Using default camera.', 'info');
        }
    } catch (error) {
        console.error('Scanner start error:', error);
        showNotification('Scanner Error', `Failed to start scanner: ${error.message}`, 'error');
    }
}

// Stop the scanner
function stopScanner() {
    if (!isScanning) {
        return;
    }
    
    html5QrCode.stop()
        .then(() => {
            isScanning = false;
            startCameraButton.disabled = false;
            stopCameraButton.disabled = true;
            
            showNotification('Scanner Stopped', 'QR code scanner has been stopped.', 'info');
        })
        .catch((error) => {
            console.error('Scanner stop error:', error);
            showNotification('Scanner Error', `Failed to stop scanner: ${error.message}`, 'error');
        });
}

// Handle successful scan
async function onScanSuccess(qrCodeMessage) {
    try {
        // Stop scanning immediately to prevent multiple scans
        await stopScanner();
        
    // Play a success sound
    playBeepSound();
    
    // Add a success animation to the reader
    addScanAnimation('success');
    
    console.log('QR code detected:', qrCodeMessage);
    
    // Display the scanned QR code data
    displayScanResult(qrCodeMessage);
    
    // Process the scan data with the server
    await processScanData(qrCodeMessage);
    
        // Add a "Scan Again" button
        const scanAgainButton = document.createElement('button');
        scanAgainButton.className = 'btn btn-primary mt-3';
        scanAgainButton.textContent = 'Scan Another QR Code';
        scanAgainButton.onclick = startScanner;
        scanResultElement.appendChild(scanAgainButton);
        
    } catch (error) {
        console.error('Scan processing error:', error);
        showNotification('Processing Error', error.message, 'error');
        
        // Re-enable scanning if there was an error
        startScanner();
    }
}

// Handle scan failure
function onScanFailure(error) {
    // We don't need to do anything on failure during continuous scanning
    // console.error('QR code scan error:', error);
}

// Display the scan result
function displayScanResult(qrData) {
    try {
        // Try to parse the QR data as JSON
        const parsedData = JSON.parse(qrData);
        
        // Create a formatted HTML output
        let resultHTML = `
            <div class="alert alert-success">
                <h5>QR Code Scan Successful</h5>
                <hr>
                <p><strong>Vehicle Number:</strong> ${parsedData.vehicleNumber || 'N/A'}</p>
                <p><strong>Driver Name:</strong> ${parsedData.driverName || 'N/A'}</p>
                <p><strong>Contact:</strong> ${parsedData.contactNumber || 'N/A'}</p>
            </div>
        `;
        
        scanResultElement.innerHTML = resultHTML;
    } catch (error) {
        // If parsing fails, display the raw data
        scanResultElement.innerHTML = `
            <div class="alert alert-warning">
                <h5>QR Code Detected (Invalid Format)</h5>
                <hr>
                <p><strong>Raw Data:</strong> ${qrData}</p>
                <p class="text-danger">The QR code data is not in the expected JSON format. Please ensure the QR code contains valid vehicle information.</p>
                <p class="text-muted small">Expected format: {"vehicleNumber": "ABC123", "driverName": "John Doe", "contactNumber": "1234567890"}</p>
            </div>
        `;
    }
}

// Process scan data with the server
async function processScanData(qrData) {
    // Get selected entry gate
    const entryGate = entryGateSelect.value;
    
    try {
        // Add debug logging
        console.log('Processing QR with token:', authState.token);
        
        const response = await fetch(`${API_BASE_URL}/parking/process-qr`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authState.token}`
            },
            body: JSON.stringify({
                qrData,
                entryGate
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            // Check if it's a vehicle already in parking error
            if (data.message && data.message.includes('already in the parking lot')) {
                scanResultElement.innerHTML = `
                    <div class="alert alert-warning">
                        <h5>Vehicle Already Parked</h5>
                        <hr>
                        <p><i class="bi bi-exclamation-triangle me-2"></i>${data.message}</p>
                        <p class="text-muted small">This vehicle must exit before it can enter again.</p>
                    </div>
                `;
                throw new Error(data.message);
            }
            
            // Check if it's an authentication error
            if (response.status === 401) {
                console.log('Authentication error, attempting token refresh...');
                
                // Try to refresh the token
                if (typeof refreshToken === 'function') {
                    const refreshed = await refreshToken();
                    
                    if (refreshed) {
                        // Retry the request with the new token
                        console.log('Token refreshed, retrying scan...');
                        return processScanData(qrData);
                    } else {
                        // If refresh failed, prompt for login
                        throw new Error('Session expired. Please log in again.');
                    }
                } else {
                    // If no refresh function available, just log out
                    if (typeof logout === 'function') {
                        logout();
                    }
                    throw new Error('Authentication failed. Please log in again.');
                }
            }
            
            throw new Error(data.message || 'Failed to process QR code');
        }
        
        // Show success notification
        showNotification('Entry Recorded', 'Vehicle entry has been successfully recorded.', 'success');
        
        // Update the scan result to show success with entry details
        scanResultElement.innerHTML = `
            <div class="alert alert-success">
                <h5><i class="bi bi-check-circle me-2"></i>Entry Recorded Successfully</h5>
                <hr>
                <p><strong>Vehicle Number:</strong> ${data.data.vehicleNumber}</p>
                <p><strong>Driver Name:</strong> ${data.data.driverName}</p>
                <p><strong>Entry Time:</strong> ${new Date(data.data.entryTime).toLocaleString()}</p>
                <p><strong>Entry Gate:</strong> ${data.data.entryGate}</p>
            </div>
        `;
        
        // Refresh active entries table
        fetchActiveEntries();
        
        return data;
    } catch (error) {
        console.error('QR processing error:', error);
        showNotification('Processing Error', error.message, 'error');
        
        // If not already showing a specific error message, show generic error
        if (!scanResultElement.innerHTML.includes('Vehicle Already Parked')) {
        scanResultElement.innerHTML = `
            <div class="alert alert-danger">
                <h5>Processing Error</h5>
                <hr>
                <p>${error.message}</p>
            </div>
        `;
        }
        
        // Add error animation
        addScanAnimation('error');
        
        return null;
    }
}

// Fetch active parking entries
async function fetchActiveEntries() {
    try {
        // Debug logging
        console.log('Fetching active entries with token:', authState.token);
        
        // Check if we have a valid token
        if (!authState.token) {
            throw new Error('Authentication required. Please log in again.');
        }
        
        const response = await fetch(`${API_BASE_URL}/parking/active`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${authState.token}`
            }
        });
        
        // Handle authentication errors
        if (response.status === 401) {
            console.log('Authentication error while fetching entries, attempting token refresh...');
            
            // Try to refresh the token
            if (typeof refreshToken === 'function') {
                const refreshed = await refreshToken();
                
                if (refreshed) {
                    // Retry the request with the new token
                    console.log('Token refreshed, retrying fetch...');
                    return fetchActiveEntries();
                } else {
                    // If refresh failed, prompt for login
                    throw new Error('Session expired. Please log in again.');
                }
            } else {
                // If no refresh function available, just log out
                if (typeof logout === 'function') {
                    logout();
                }
                throw new Error('Authentication failed. Please log in again.');
            }
        }
        
        if (!response.ok) {
            throw new Error('Failed to fetch active entries');
        }
        
        const data = await response.json();
        
        // Update the table with fetched entries
        updateEntriesTable(data.data || []);
        
        return data;
    } catch (error) {
        console.error('Fetch entries error:', error);
        
        // Show error in the table
        if (entriesTable) {
            entriesTable.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        ${error.message}
                    </td>
                </tr>
            `;
        }
        
        return null;
    }
}

// Update the entries table with data
function updateEntriesTable(entries) {
    const tableBody = entriesTable.querySelector('tbody');
    
    // Clear existing rows
    tableBody.innerHTML = '';
    
    if (entries.length === 0) {
        // No entries
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center">No active vehicles in the parking lot</td>
            </tr>
        `;
        return;
    }
    
    // Add rows for each entry
    entries.forEach(entry => {
        const entryTime = new Date(entry.entryTime).toLocaleString();
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${entry.vehicleNumber}</td>
            <td>${entry.driverName}</td>
            <td>${entryTime}</td>
            <td>${entry.entryGate}</td>
            <td>
                <button class="btn btn-sm btn-info view-details" data-id="${entry._id}">
                    <i class="fas fa-info-circle"></i> Details
                </button>
                <button class="btn btn-sm btn-success record-exit" data-id="${entry._id}">
                    <i class="fas fa-sign-out-alt"></i> Exit
                </button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
    
    // Add event listeners to the buttons
    addTableButtonListeners();
}

// Add event listeners to table buttons
function addTableButtonListeners() {
    // View details buttons
    const viewDetailsButtons = document.querySelectorAll('.view-details');
    viewDetailsButtons.forEach(button => {
        button.addEventListener('click', () => {
            const entryId = button.getAttribute('data-id');
            viewEntryDetails(entryId);
        });
    });
    
    // Record exit buttons
    const recordExitButtons = document.querySelectorAll('.record-exit');
    recordExitButtons.forEach(button => {
        button.addEventListener('click', () => {
            const entryId = button.getAttribute('data-id');
            recordVehicleExit(entryId);
        });
    });
}

// View entry details
function viewEntryDetails(entryId) {
    // Find the entry in the table
    const row = document.querySelector(`button[data-id="${entryId}"]`).closest('tr');
    const vehicleNumber = row.cells[0].textContent;
    const driverName = row.cells[1].textContent;
    const entryTime = row.cells[2].textContent;
    const entryGate = row.cells[3].textContent;
    
    // Populate the modal with data
    const modalContent = document.getElementById('scan-details-content');
    modalContent.innerHTML = `
        <div class="card">
            <div class="card-body">
                <p><strong>Vehicle Number:</strong> ${vehicleNumber}</p>
                <p><strong>Driver Name:</strong> ${driverName}</p>
                <p><strong>Entry Time:</strong> ${entryTime}</p>
                <p><strong>Entry Gate:</strong> ${entryGate}</p>
                <p><strong>Entry ID:</strong> ${entryId}</p>
            </div>
        </div>
    `;
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('scan-details-modal'));
    modal.show();
}

// Record vehicle exit
async function recordVehicleExit(entryId) {
    try {
        // Debug logging
        console.log('Recording exit for entry ID:', entryId, 'with token:', authState.token);
        
        const response = await fetch(`${API_BASE_URL}/parking/exit/${entryId}`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${authState.token}`
            }
        });
        
        const data = await response.json();
        console.log('Exit response:', data);
        
        if (!response.ok) {
            throw new Error(data.message || 'Failed to record vehicle exit');
        }
        
        // Show success notification
        showNotification('Exit Recorded', 'Vehicle exit has been successfully recorded.', 'success');
        
        // Refresh active entries table
        fetchActiveEntries();
        
        return data;
    } catch (error) {
        console.error('Record exit error:', error);
        showNotification('Exit Error', `Failed to record exit: ${error.message}`, 'error');
        return null;
    }
}

// Play a beep sound when QR code is scanned
function playBeepSound() {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    gainNode.gain.setValueAtTime(0.5, audioContext.currentTime);
    oscillator.start();
    oscillator.stop(audioContext.currentTime + 0.1);
}

// Add animation to the scanner after a scan
function addScanAnimation(type) {
    const readerElement = document.getElementById('reader');
    
    // Remove existing animations
    readerElement.classList.remove('success-scan', 'error-scan');
    
    // Add new animation class
    if (type === 'success') {
        readerElement.classList.add('success-scan');
    } else if (type === 'error') {
        readerElement.classList.add('error-scan');
    }
    
    // Remove the animation class after it completes
    setTimeout(() => {
        readerElement.classList.remove('success-scan', 'error-scan');
    }, 2000);
}

// Initialize scanner when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('reader')) {
        initScanner();
    }
}); 