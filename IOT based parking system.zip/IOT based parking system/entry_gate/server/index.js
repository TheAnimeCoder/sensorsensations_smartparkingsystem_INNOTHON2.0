const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

/**
 * Parking System - Entry Gate Server
 * This server handles the entry gate operations for the parking system,
 * including QR code scanning and vehicle entry registration.
 */

// Import routes
const parkingRoutes = require('./routes/parkingRoutes');
const authRoutes = require('./routes/authRoutes');

const app = express();
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/parking';
const MOCK_DB = process.env.MOCK_DB === 'true';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Routes
app.use('/api/parking', parkingRoutes);
app.use('/api/auth', authRoutes);

// Serve the entry gate interface
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Function to start the entry gate server
const startServer = () => {
  app.listen(PORT, () => {
    console.log(`Entry Gate Server running on port ${PORT}`);
    if (MOCK_DB) {
      console.log('Running with mock database - for development/testing only');
    }
  });
};

// Connect to MongoDB or use mock database
if (MOCK_DB) {
  console.log('Mock database mode is enabled. Skipping MongoDB connection.');
  startServer();
} else {
  mongoose.connect(MONGODB_URI)
    .then(() => {
      console.log('Connected to MongoDB');
      // Start the server after successful database connection
      startServer();
    })
    .catch(err => {
      console.error('Failed to connect to MongoDB:', err);
      console.log('Falling back to mock database mode...');
      
      // Set global flag for mock mode
      global.MOCK_DB = true;
      
      // Start server anyway
      startServer();
    });
}

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Internal Server Error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

module.exports = app; 