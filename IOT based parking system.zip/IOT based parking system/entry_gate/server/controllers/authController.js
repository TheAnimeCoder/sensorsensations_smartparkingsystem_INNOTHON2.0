const jwt = require('jsonwebtoken');
const User = require('../models/User');

// JWT secret from environment variables (fallback to a default for development)
const JWT_SECRET = process.env.JWT_SECRET || 'parking_security_key_change_in_production';

// Mock user for development/testing when no DB is available
const MOCK_ADMIN = {
  _id: '507f1f77bcf86cd799439011',
  name: 'Admin User',
  email: 'admin@parking.com',
  role: 'admin',
  isActive: true,
  lastLogin: new Date()
};

// Generate JWT Token
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: '7d' } // Extended from 12h to 7 days for better user experience
  );
};

// Generate Refresh Token (with longer expiry)
const generateRefreshToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email },
    JWT_SECRET + '-refresh',
    { expiresIn: '30d' } // 30 days for refresh token
  );
};

// Check if we're using mock database
const isMockDB = () => {
  return process.env.MOCK_DB === 'true' || global.MOCK_DB === true;
};

// Register a new user
exports.register = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    if (isMockDB()) {
      // In mock mode, just pretend registration worked
      const token = generateToken({ 
        _id: '507f1f77bcf86cd799439022', 
        email, 
        role: role || 'operator' 
      });
      
      const refreshToken = generateRefreshToken({ 
        _id: '507f1f77bcf86cd799439022', 
        email
      });
      
      return res.status(201).json({
        success: true,
        message: 'User registered successfully (mock mode)',
        data: {
          user: {
            id: '507f1f77bcf86cd799439022',
            name,
            email,
            role: role || 'operator'
          },
          token,
          refreshToken
        }
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User with this email already exists'
      });
    }

    // Create a new user
    const user = new User({
      name,
      email,
      password,
      role: role || 'operator' // Default to operator if role not specified
    });

    await user.save();

    // Generate tokens
    const token = generateToken(user);
    const refreshToken = generateRefreshToken(user);

    // Return user data and tokens
    res.status(201).json({
      success: true,
      message: 'User registered successfully',
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role
        },
        token,
        refreshToken
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Login user
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Special handling for mock mode
    if (isMockDB()) {
      // Check if matching admin credentials (for mock mode)
      if (email === 'admin@parking.com' && password === 'admin123') {
        const token = generateToken(MOCK_ADMIN);
        const refreshToken = generateRefreshToken(MOCK_ADMIN);
        
        return res.status(200).json({
          success: true,
          message: 'Login successful (mock mode)',
          data: {
            user: {
              id: MOCK_ADMIN._id,
              name: MOCK_ADMIN.name,
              email: MOCK_ADMIN.email,
              role: MOCK_ADMIN.role
            },
            token,
            refreshToken
          }
        });
      } else {
        return res.status(401).json({
          success: false,
          message: 'Invalid credentials'
        });
      }
    }

    // Regular DB mode from here
    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(401).json({
        success: false,
        message: 'User account is inactive'
      });
    }

    // Verify password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Update last login
    user.lastLogin = Date.now();
    await user.save();

    // Generate tokens
    const token = generateToken(user);
    const refreshToken = generateRefreshToken(user);

    // Return user data and tokens
    res.status(200).json({
      success: true,
      message: 'Login successful',
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role
        },
        token,
        refreshToken
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Get current user profile
exports.getProfile = async (req, res) => {
  try {
    if (isMockDB()) {
      return res.status(200).json({
        success: true,
        data: {
          user: MOCK_ADMIN
        }
      });
    }

    const user = await User.findById(req.user._id).select('-password');
    
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.status(200).json({
      success: true,
      data: {
        user
      }
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Verify token endpoint
exports.verifyToken = async (req, res) => {
  // If request reaches here, it means the token is valid
  // (auth middleware has already verified it)
  return res.status(200).json({
    success: true,
    message: 'Token is valid',
    data: {
      user: req.user
    }
  });
};

// Refresh token endpoint
exports.refreshToken = async (req, res) => {
  try {
    const { email, refreshToken } = req.body;
    
    if (!email || !refreshToken) {
      return res.status(400).json({
        success: false,
        message: 'Email and refresh token are required'
      });
    }
    
    // Special handling for mock mode
    if (isMockDB()) {
      // For mock mode, check if email matches our mock admin
      if (email === MOCK_ADMIN.email) {
        try {
          // Verify the refresh token
          jwt.verify(refreshToken, JWT_SECRET + '-refresh');
          
          // Generate new tokens
          const newToken = generateToken(MOCK_ADMIN);
          const newRefreshToken = generateRefreshToken(MOCK_ADMIN);
          
          return res.status(200).json({
            success: true,
            message: 'Token refreshed successfully (mock mode)',
            data: {
              token: newToken,
              refreshToken: newRefreshToken
            }
          });
        } catch (error) {
          return res.status(401).json({
            success: false,
            message: 'Invalid refresh token'
          });
        }
      } else {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
    }
    
    // Regular DB mode
    try {
      // Verify the refresh token
      const decoded = jwt.verify(refreshToken, JWT_SECRET + '-refresh');
      
      // Find user by email
      const user = await User.findOne({ email });
      
      if (!user || user._id.toString() !== decoded.id) {
        return res.status(401).json({
          success: false,
          message: 'Invalid refresh token'
        });
      }
      
      // Check if user is active
      if (!user.isActive) {
        return res.status(401).json({
          success: false,
          message: 'User account is inactive'
        });
      }
      
      // Generate new tokens
      const newToken = generateToken(user);
      const newRefreshToken = generateRefreshToken(user);
      
      return res.status(200).json({
        success: true,
        message: 'Token refreshed successfully',
        data: {
          token: newToken,
          refreshToken: newRefreshToken
        }
      });
    } catch (error) {
      return res.status(401).json({
        success: false,
        message: 'Invalid refresh token'
      });
    }
  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
}; 