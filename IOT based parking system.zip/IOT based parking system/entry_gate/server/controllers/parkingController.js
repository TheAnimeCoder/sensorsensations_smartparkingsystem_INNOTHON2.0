const ParkingEntry = require('../models/ParkingEntry');

// Mock data for development/testing when no DB is available
let MOCK_ENTRIES = [
  {
    _id: 'test_entry_123',
    vehicleNumber: 'ABC1234',
    driverName: 'John Doe',
    contactNumber: '9876543210',
    entryTime: new Date(),
    exitTime: null,
    isActive: true,
    qrData: JSON.stringify({
      vehicleNumber: 'ABC1234',
      driverName: 'John Doe',
      contactNumber: '9876543210'
    }),
    entryGate: 'GATE1',
    scanOperator: 'user1',
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

// Check if we're using mock database
const isMockDB = () => {
  return process.env.MOCK_DB === 'true' || global.MOCK_DB === true;
};

// Process QR code scan
exports.processQRCode = async (req, res) => {
  try {
    const { qrData, entryGate } = req.body;
    const scanOperator = req.user._id;

    if (!qrData) {
      return res.status(400).json({
        success: false,
        message: 'QR code data is required'
      });
    }

    // Attempt to parse the QR data (assuming it's in JSON format)
    let parsedData;
    try {
      parsedData = JSON.parse(qrData);
    } catch (error) {
      return res.status(400).json({
        success: false,
        message: 'Invalid QR code format. QR code should contain valid JSON data.'
      });
    }

    // Extract vehicle information from parsed data
    const { vehicleNumber, driverName, contactNumber } = parsedData;

    if (!vehicleNumber || !driverName) {
      return res.status(400).json({
        success: false,
        message: 'QR code data is incomplete. Vehicle number and driver name are required.'
      });
    }

    // Mock DB handling
    if (isMockDB()) {
      // Check if vehicle already exists in mock entries
      const existingEntry = MOCK_ENTRIES.find(entry => 
        entry.vehicleNumber === vehicleNumber && entry.isActive === true
      );

      if (existingEntry) {
        return res.status(400).json({
          success: false,
          message: 'Vehicle is already in the parking lot',
          data: existingEntry
        });
      }

      // Create a new mock entry
      const newEntry = {
        _id: 'entry_' + Date.now(),
        vehicleNumber,
        driverName,
        contactNumber: contactNumber || '',
        entryTime: new Date(),
        exitTime: null,
        isActive: true,
        qrData,
        entryGate: entryGate || 'GATE1',
        scanOperator,
        createdAt: new Date(),
        updatedAt: new Date()
      };

      // Add to mock entries
      MOCK_ENTRIES.push(newEntry);

      return res.status(201).json({
        success: true,
        message: 'Vehicle entry recorded successfully (mock mode)',
        data: newEntry
      });
    }

    // Regular DB mode from here
    // Check if the vehicle is already in the parking lot
    const existingEntry = await ParkingEntry.findOne({
      vehicleNumber,
      isActive: true
    });

    if (existingEntry) {
      return res.status(400).json({
        success: false,
        message: 'Vehicle is already in the parking lot',
        data: existingEntry
      });
    }

    // Create a new parking entry
    const newEntry = new ParkingEntry({
      vehicleNumber,
      driverName,
      contactNumber: contactNumber || '',
      entryTime: new Date(),
      qrData,
      entryGate: entryGate || 'GATE1',
      scanOperator
    });

    await newEntry.save();

    res.status(201).json({
      success: true,
      message: 'Vehicle entry recorded successfully',
      data: newEntry
    });
  } catch (error) {
    console.error('QR scan error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while processing QR code',
      error: error.message
    });
  }
};

// Get all active parking entries
exports.getActiveEntries = async (req, res) => {
  try {
    if (isMockDB()) {
      // Filter active entries for mock mode
      const activeEntries = MOCK_ENTRIES.filter(entry => entry.isActive === true);
      
      return res.status(200).json({
        success: true,
        count: activeEntries.length,
        data: activeEntries
      });
    }

    const entries = await ParkingEntry.find({ isActive: true })
      .sort({ entryTime: -1 })
      .populate('scanOperator', 'name email');

    res.status(200).json({
      success: true,
      count: entries.length,
      data: entries
    });
  } catch (error) {
    console.error('Get entries error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Record vehicle exit
exports.recordExit = async (req, res) => {
  try {
    const { id } = req.params;

    if (isMockDB()) {
      // Find the entry in mock data
      const entryIndex = MOCK_ENTRIES.findIndex(entry => entry._id === id);
      
      if (entryIndex === -1) {
        return res.status(404).json({
          success: false,
          message: 'Parking entry not found'
        });
      }

      if (!MOCK_ENTRIES[entryIndex].isActive) {
        return res.status(400).json({
          success: false,
          message: 'Vehicle has already exited'
        });
      }

      // Update the entry
      MOCK_ENTRIES[entryIndex].exitTime = new Date();
      MOCK_ENTRIES[entryIndex].isActive = false;
      MOCK_ENTRIES[entryIndex].updatedAt = new Date();

      return res.status(200).json({
        success: true,
        message: 'Vehicle exit recorded successfully (mock mode)',
        data: MOCK_ENTRIES[entryIndex]
      });
    }

    const entry = await ParkingEntry.findById(id);

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'Parking entry not found'
      });
    }

    if (!entry.isActive) {
      return res.status(400).json({
        success: false,
        message: 'Vehicle has already exited'
      });
    }

    // Update entry with exit information
    entry.exitTime = new Date();
    entry.isActive = false;
    await entry.save();

    res.status(200).json({
      success: true,
      message: 'Vehicle exit recorded successfully',
      data: entry
    });
  } catch (error) {
    console.error('Record exit error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

// Get entry by vehicle number
exports.getEntryByVehicleNumber = async (req, res) => {
  try {
    const { vehicleNumber } = req.params;

    if (isMockDB()) {
      // Find active entry with this vehicle number
      const entry = MOCK_ENTRIES.find(
        entry => entry.vehicleNumber === vehicleNumber && entry.isActive === true
      );
      
      if (!entry) {
        return res.status(404).json({
          success: false,
          message: 'No active entry found for this vehicle'
        });
      }

      return res.status(200).json({
        success: true,
        data: entry
      });
    }

    const entry = await ParkingEntry.findOne({
      vehicleNumber,
      isActive: true
    }).populate('scanOperator', 'name email');

    if (!entry) {
      return res.status(404).json({
        success: false,
        message: 'No active entry found for this vehicle'
      });
    }

    res.status(200).json({
      success: true,
      data: entry
    });
  } catch (error) {
    console.error('Get by vehicle number error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
}; 