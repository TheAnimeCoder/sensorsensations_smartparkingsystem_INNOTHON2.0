const express = require('express');
const router = express.Router();
const parkingController = require('../controllers/parkingController');
const { auth, isAdmin } = require('../middleware/auth');

// All routes are protected with authentication
router.use(auth);

// QR code scanning and processing
router.post('/process-qr', parkingController.processQRCode);

// Get all active entries
router.get('/active', parkingController.getActiveEntries);

// Record vehicle exit
router.put('/exit/:id', parkingController.recordExit);

// Get entry by vehicle number
router.get('/vehicle/:vehicleNumber', parkingController.getEntryByVehicleNumber);

module.exports = router; 