const jwt = require('jsonwebtoken');
const User = require('../models/User');

// JWT secret from environment variables (fallback to a default for development)
const JWT_SECRET = process.env.JWT_SECRET || 'parking_security_key_change_in_production';

// Mock admin user for development/testing
const MOCK_ADMIN = {
  _id: '507f1f77bcf86cd799439011',
  name: 'Admin User',
  email: 'admin@parking.com',
  role: 'admin',
  isActive: true,
  lastLogin: new Date()
};

// Check if we're using mock database
const isMockDB = () => {
  return process.env.MOCK_DB === 'true' || global.MOCK_DB === true;
};

// Middleware to authenticate requests
const auth = async (req, res, next) => {
  try {
    // Get token from header
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }

    // Verify token
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // Special handling for mock mode
    if (isMockDB()) {
      // In mock mode, we'll just set the user to the mock admin
      req.user = MOCK_ADMIN;
      return next();
    }
    
    // Find user by id from token payload
    const user = await User.findById(decoded.id);
    
    if (!user || !user.isActive) {
      return res.status(401).json({ success: false, message: 'User not found or inactive' });
    }
    
    // Add user to request object
    req.user = user;
    next();
  } catch (error) {
    console.error('Auth error:', error.message);
    res.status(401).json({ success: false, message: 'Invalid token' });
  }
};

// Middleware to check if user is admin
const isAdmin = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ success: false, message: 'Admin access required' });
  }
};

module.exports = { auth, isAdmin }; 