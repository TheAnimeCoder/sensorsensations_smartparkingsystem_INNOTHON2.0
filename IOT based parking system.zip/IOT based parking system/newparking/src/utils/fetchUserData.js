import { useEffect, useState } from 'react';
import axios from 'axios';

const fetchUserData = async () => {
  try {
    const response = await axios.get('http://localhost:3000/users');
    return response.data;
  } catch (error) {
    console.error('Error fetching user data:', error);
    return [];
  }
};

export default fetchUserData;