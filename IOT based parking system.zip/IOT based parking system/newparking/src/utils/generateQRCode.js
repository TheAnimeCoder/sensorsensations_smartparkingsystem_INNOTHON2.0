import QRCode from 'qrcode';

const generateQRCode = async (vehicleDetails) => {
  try {
    const dataString = JSON.stringify(vehicleDetails);

    console.log('QR Code Data:');
    console.log(dataString);

    // Generate the QR code as a data URL
    const qrCodeDataUrl = await QRCode.toDataURL(dataString, {
      errorCorrectionLevel: 'H',
      margin: 2,
      scale: 10,
      width: 400,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    });

    console.log('QR code generated as a data URL.');
    return qrCodeDataUrl;
  } catch (err) {
    console.error('Error generating QR code:', err);
    throw err;
  }
};

export default generateQRCode;