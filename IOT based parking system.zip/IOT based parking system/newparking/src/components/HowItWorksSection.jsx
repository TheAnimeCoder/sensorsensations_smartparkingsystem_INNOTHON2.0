export default function HowItWorksSection() {
  const steps = [
    {
      icon: "fas fa-qrcode",
      number: 1,
      title: "Scan QR Code",
      description: "Use our mobile app or kiosk to scan your unique QR code for entry."
    },
    {
      icon: "fas fa-map-marker-alt",
      number: 2,
      title: "Get Your Slot",
      description: "Receive your assigned parking slot location instantly on your device."
    },
    {
      icon: "fas fa-parking",
      number: 3,
      title: "Park Guided",
      description: "Follow LED indicators to your spot and park with ease."
    }
  ]

  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-[#1d74e9] mb-4">How It Works</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">Experience a seamless parking process with our simple 3-step system.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="text-center">
              <div className="flex items-center justify-center h-24 w-24 bg-[#1d74e9] rounded-full mb-6 mx-auto relative">
                <i className={`${step.icon} text-white text-3xl`}></i>
                <div className="absolute -top-3 -right-3 h-10 w-10 bg-[#22c55e] rounded-full flex items-center justify-center text-white font-bold text-xl">
                  {step.number}
                </div>
              </div>
              <h3 className="text-xl font-semibold text-[#1d74e9] mb-3">{step.title}</h3>
              <p className="text-gray-600">{step.description}</p>
            </div>
          ))}
        </div>
        
      </div>
    </section>
  )
}