import React, { useState } from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const Register = () => {
  const [formData, setFormData] = useState({
    firstname: '',
    lastname: '',
    email: '',
    password: '',
    confirmPassword: '',
    contactNumber: ''
  });

  const [message, setMessage] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      setMessage('Password and confirm password do not match!');
      return;
    }

    try {
      // Check if email already exists
      const existingUsersResponse = await fetch('http://localhost:3000/users');
      const existingUsers = await existingUsersResponse.json();

      const emailExists = existingUsers.some(user => user.email === formData.email);
      if (emailExists) {
        setMessage('An account with this email already exists!');
        return;
      }

      // Proceed with registration
      const response = await fetch('http://localhost:3000/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          firstname: formData.firstname,
          lastname: formData.lastname,
          email: formData.email,
          password: formData.password,
          contactNumber: formData.contactNumber
        })
      });

      if (response.ok) {
        setMessage('Registration successful!');
        setFormData({ firstname: '', lastname: '', email: '', password: '', confirmPassword: '', contactNumber: '' });
      } else {
        setMessage('Failed to register. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <StyledWrapper>
      <form className="form" onSubmit={handleSubmit}>
        <p className="title">Register </p>
        <p className="message">Signup now and get full access to our app. </p>
        <div className="flex">
          <label>
            <input
              required
              placeholder
              type="text"
              name="firstname"
              value={formData.firstname}
              onChange={handleChange}
              className="input"
            />
            <span>Firstname</span>
          </label>
          <label>
            <input
              required
              placeholder
              type="text"
              name="lastname"
              value={formData.lastname}
              onChange={handleChange}
              className="input"
            />
            <span>Lastname</span>
          </label>
        </div>  
        <label>
          <input
            required
            placeholder
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            className="input"
          />
          <span>Email</span>
        </label> 
        <label>
          <input
            required
            placeholder
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            className="input"
          />
          <span>Password</span>
        </label>
        <label>
          <input
            required
            placeholder
            type="password"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            className="input"
          />
          <span>Confirm password</span>
        </label>
        <label>
          <input
            required
            type="text"
            name="contactNumber"
            value={formData.contactNumber}
            onChange={handleChange}
            className="input"
          />
          <span>Contact Number</span>
        </label>
        <button className="submit">Submit</button>
        {message && <p className="message">{message}</p>}
        <p className="signin">Already have an account? <Link to="/login">Login here</Link></p>
      </form>
    </StyledWrapper>
  );
}

const StyledWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;

  .form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }

  .title {
    font-size: 2.5rem;
    color: #2c3e50;
    margin-bottom: 20px;
    font-family: 'Poppins', sans-serif;
    font-weight: 700;
  }

  .message, .signin {
    color: rgba(88, 87, 87, 0.822);
    font-size: 14px;
  }

  .signin {
    font-size: 0.9rem;
    color: #34495e;
  }

  .signin a {
    color: #3498db;
    text-decoration: none;
    font-weight: 600;
  }

  .signin a:hover {
    text-decoration: underline;
  }

  .flex {
    display: flex;
    width: 100%;
    gap: 6px;
  }

  .form label {
    position: relative;
  }

  .form label .input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 10px;
    font-size: 1rem;
    font-family: 'Roboto', sans-serif;
    color: black; /* Set input text color to black */
  }

  .form label .input + span {
    position: absolute;
    left: 10px;
    top: 15px;
    color: grey;
    font-size: 0.9em;
    cursor: text;
    transition: 0.3s ease;
  }

  .form label .input:placeholder-shown + span {
    top: 15px;
    font-size: 0.9em;
  }

  .form label .input:focus + span,.form label .input:valid + span {
    top: 30px;
    font-size: 0.7em;
    font-weight: 600;
  }

  .form label .input:valid + span {
    color: green;
  }

  .submit {
    padding: 12px;
    font-size: 1rem;
    color: #fff;
    background: #3498db;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.3s ease;
  }

  .submit:hover {
    background: #2980b9;
  }

  @keyframes pulse {
    from {
      transform: scale(0.9);
      opacity: 1;
    }

    to {
      transform: scale(1.8);
      opacity: 0;
    }
  }`;

export default Register;
