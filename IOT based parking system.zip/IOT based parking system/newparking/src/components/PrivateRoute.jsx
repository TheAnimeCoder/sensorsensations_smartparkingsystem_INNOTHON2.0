import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const PrivateRoute = ({ children }) => {
  const navigate = useNavigate();

  useEffect(() => {
    const checkLoginStatus = async () => {
      try {
        const response = await fetch('http://localhost:3000/users');
        const users = await response.json();
        const loggedInUser = users.find(user => user.isLoggedIn);

        if (!loggedInUser) {
          navigate('/login');
        }
      } catch (error) {
        console.error('Error checking login status:', error);
        navigate('/login');
      }
    };

    checkLoginStatus();
  }, []);

  return children;
};

export default PrivateRoute;