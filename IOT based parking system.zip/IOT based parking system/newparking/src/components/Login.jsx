import React, { useState } from 'react';
import styled from 'styled-components';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Login = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.get('http://localhost:3000/users');
      const users = response.data;

      const user = users.find(
        (u) => u.email === email && u.password === password
      );

      if (user) {
        // Update the isLoggedIn field in db.json
        await axios.patch(`http://localhost:3000/users/${user.id}`, {
          isLoggedIn: true,
        });

        navigate('/user'); // Redirect to home page on successful login
      } else {
        setErrorMessage('Invalid email or password'); // Set error message
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      setErrorMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <StyledWrapper>
      <div className="form-container">
        <p className="title">Welcome back</p>
        <form className="form" onSubmit={handleLogin}>
          <input
            type="email"
            className="input"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <input
            type="password"
            className="input"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {errorMessage && <p className="error-message">{errorMessage}</p>} {/* Display error message */}
          <button type="submit" className="form-btn">Log in</button>
        </form>
        <p className="sign-up-label">
          Don't have an account?<span className="sign-up-link"><Link to="/register">Sign up</Link></span>
        </p>
        
      </div>
    </StyledWrapper>
  );
};

const StyledWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;

  .form-container {
    width: 400px;
    height: auto;
    background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    border-radius: 15px;
    padding: 30px;
    text-align: center;
  }

  .title {
    font-size: 2.5rem;
    color: #2c3e50;
    margin-bottom: 20px;
    font-family: 'Poppins', sans-serif;
    font-weight: 700;
  }

  .form {
    display: flex;
    flex-direction: column;
    gap: 15px;
  }

  .input {
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 10px;
    font-size: 1rem;
    font-family: 'Roboto', sans-serif;
    color: black; /* Set input text color to black */
  }

  .error-message {
    color: red;
    font-size: 0.9rem;
    margin-top: -10px;
  }

  .form-btn {
    padding: 12px;
    font-size: 1rem;
    color: #fff;
    background: #3498db;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.3s ease;
  }

  .form-btn:hover {
    background: #2980b9;
  }

  .sign-up-label {
    font-size: 0.9rem;
    color: #34495e;
  }

  .sign-up-link {
    color: #3498db;
    text-decoration: none;
    font-weight: 600;
  }

  .sign-up-link:hover {
    text-decoration: underline;
  }

  .buttons-container {
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    margin-top: 20px;
    gap: 15px;
  }

  .apple-login-button,
      .google-login-button {
    border-radius: 20px;
    box-sizing: border-box;
    padding: 10px 15px;
    box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
          rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: "Lucida Sans", "Lucida Sans Regular", "Lucida Grande",
          "Lucida Sans Unicode", Geneva, Verdana, sans-serif;
    font-size: 11px;
    gap: 5px;
  }

  .apple-login-button {
    background-color: #000;
    color: #fff;
    border: 2px solid #000;
  }

  .google-login-button {
    border: 2px solid #747474;
  }

  .apple-icon,
      .google-icon {
    font-size: 18px;
    margin-bottom: 1px;
  }`;

export default Login;
