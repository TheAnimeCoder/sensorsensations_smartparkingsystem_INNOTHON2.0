import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className={`fixed w-full h-[4rem] bg-white z-50 ${scrollPosition > 10 ? 'shadow-md' : ''}`}>
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <a href="#" className="flex items-center">
            <i className="fas fa-parking text-3xl text-[#1d74e9] mr-2"></i>
            <span className="text-xl font-bold text-[#1d74e9]">SmartPark</span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link to="/" className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300">Home</Link>
            <a href="#features" className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300">Features</a>
            <a href="#how-it-works" className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300">How It Works</a>
            <Link to="/login" className="font-normal bg-[#1d74e9] text-white px-4 py-2 rounded-md hover:bg-[#1259b8] transition duration-300">Login</Link>
          </nav>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-700 focus:outline-none"
            onClick={toggleMobileMenu}
            aria-label="Toggle mobile menu"
          >
            <i className="fas fa-bars text-2xl"></i>
          </button>
        </div>

        {/* Mobile Navigation */}
        <nav className={`${mobileMenuOpen ? 'block' : 'hidden'} md:hidden py-4 bg-white`}>
          <div className="flex flex-col space-y-4">
            <Link 
              to="/" 
              className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300"
              onClick={closeMobileMenu}
            >
              Home
            </Link>
            <a 
              href="#features" 
              className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300"
              onClick={closeMobileMenu}
            >
              Features
            </a>
            <a 
              href="#how-it-works" 
              className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300"
              onClick={closeMobileMenu}
            >
              How It Works
            </a>
            <a 
              href="#availability" 
              className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300"
              onClick={closeMobileMenu}
            >
              Availability
            </a>
            <a 
              href="#contact" 
              className="font-medium text-gray-700 hover:text-[#1d74e9] transition duration-300"
              onClick={closeMobileMenu}
            >
              Contact
            </a>
            <Link 
              to="/login" 
              className="font-medium bg-[#1d74e9] text-white px-4 py-2 rounded-md hover:bg-[#1259b8] transition duration-300 w-fit"
              onClick={closeMobileMenu}
            >
              Login
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}