import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import SecondaryNavbar from './SecondaryNavbar';
import fetchUserData from '../utils/fetchUserData';

const Wallet = () => {
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState('');
  const [isTopUpFormVisible, setIsTopUpFormVisible] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState('');

  useEffect(() => {
    const getUserData = async () => {
      const users = await fetchUserData();
      const userData = users[0]; // Assuming the first user is the logged-in user
      if (userData.walletBalance == null) {
        userData.walletBalance = 0; // Initialize wallet balance to 0 if undefined or null
      }
      setUser(userData);
    };

    getUserData();
  }, []);

  const handleTopUpSubmit = (e) => {
    e.preventDefault();
    const amount = parseFloat(topUpAmount);
    if (!isNaN(amount) && amount > 0) {
      setUser({ ...user, walletBalance: user.walletBalance + amount });
      setMessage(`Wallet topped up with ₹${amount}`);
      setTopUpAmount('');
      setIsTopUpFormVisible(false);
    } else {
      setMessage('Please enter a valid amount.');
    }
  };

  const handleTopUpClick = () => {
    setIsTopUpFormVisible(true);
  };

  if (!user) {
    return <p>Loading...</p>;
  }

  return (
    <StyledWrapper>
      <SecondaryNavbar user={user} />
      <div className="wallet-container">
        <h1 className="title">Wallet</h1>
        <h2 className="username">Welcome, {user.firstname} {user.lastname}!</h2>
        <p className="balance">Current Balance: <strong>₹{user.walletBalance || 0}</strong></p>
        <button className="top-up-button" onClick={handleTopUpClick}>Top Up</button>
        {isTopUpFormVisible && (
          <form onSubmit={handleTopUpSubmit} className="top-up-form">
            <input
              type="number"
              value={topUpAmount}
              onChange={(e) => setTopUpAmount(e.target.value)}
              placeholder="Enter amount"
              className="top-up-input"
            />
            <button type="submit" className="submit-button">Done</button>
          </form>
        )}
        {message && <p className="message">{message}</p>}
      </div>
    </StyledWrapper>
  );
};

const StyledWrapper = styled.div`
  .wallet-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 70vh;
    width: 80%;
    max-width: 1200px;
    background: linear-gradient(135deg, #ffffff, #f0f4f8);
    text-align: center;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
    margin: auto;
  }

  .title {
    font-size: 2.5rem;
    color: #2c3e50;
    margin-bottom: 20px;
    font-family: 'Poppins', sans-serif;
    font-weight: 700;
  }

  .username {
    font-size: 1.5rem;
    color: #34495e;
    margin-bottom: 20px;
    font-family: 'Roboto', sans-serif;
  }

  .balance {
    font-size: 2rem;
    color: #27ae60;
    font-family: 'Roboto', sans-serif;
    margin-bottom: 30px;
  }

  .top-up-button {
    margin-top: 20px;
    padding: 15px 30px;
    font-size: 1.2rem;
    color: #fff;
    background-color: #3498db;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-family: 'Roboto', sans-serif;
    transition: background-color 0.3s ease, transform 0.2s ease;
  }

  .top-up-button:hover {
    background-color: #2980b9;
    transform: scale(1.05);
  }

  .top-up-form {
    margin-top: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 15px;
  }

  .top-up-input {
    padding: 15px;
    font-size: 1rem;
    border: 1px solid #3498db;
    border-radius: 10px;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    color: black; /* Set input text color to black */
  }

  .submit-button {
    padding: 15px 30px;
    font-size: 1rem;
    color: #fff;
    background-color: #3498db;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
  }

  .submit-button:hover {
    background-color: #2980b9;
    transform: scale(1.05);
  }

  .message {
    margin-top: 20px;
    font-size: 1.2rem;
    color: #27ae60;
    font-family: 'Roboto', sans-serif;
    animation: fadeIn 0.5s ease-in-out;
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
`;

export default Wallet;