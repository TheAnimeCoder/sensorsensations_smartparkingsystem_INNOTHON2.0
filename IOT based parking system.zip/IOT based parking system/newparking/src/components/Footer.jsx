import { useState } from 'react'

export default function Footer() {
  const [email, setEmail] = useState('')
  const [subscribed, setSubscribed] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (email) {
      // For demo purposes
      setSubscribed(true)
      setEmail('')
      setTimeout(() => {
        setSubscribed(false)
      }, 3000)
    }
  }

  return (
    <footer className="bg-[#1d74e9] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <i className="fas fa-parking text-2xl mr-2"></i>
              <span className="text-xl font-bold">SmartPark</span>
            </div>
            <p className="text-gray-300 mb-4">Revolutionizing urban parking with IoT technology. Find parking spaces faster, easier, and smarter.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-white transition duration-300">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition duration-300">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition duration-300">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-300 hover:text-white transition duration-300">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="#home" className="text-gray-300 hover:text-white transition duration-300">Home</a></li>
              <li><a href="#features" className="text-gray-300 hover:text-white transition duration-300">Features</a></li>
              <li><a href="#how-it-works" className="text-gray-300 hover:text-white transition duration-300">How It Works</a></li>
              <li><a href="#availability" className="text-gray-300 hover:text-white transition duration-300">Availability</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition duration-300">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-white transition duration-300">Download App</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition duration-300">Help Center</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition duration-300">FAQ</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition duration-300">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition duration-300">Terms of Service</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Subscribe</h3>
            <p className="text-gray-300 mb-4">Get the latest updates and offers.</p>
            
            {subscribed && (
              <div className="bg-green-800 p-2 rounded text-white text-sm mb-4">
                Thank you for subscribing!
              </div>
            )}
            
            <form className="flex" onSubmit={handleSubmit}>
              <input 
                type="email" 
                placeholder="Your email" 
                className="px-4 py-2 rounded-l-lg focus:outline-none text-gray-800 flex-grow"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <button 
                type="submit" 
                className="bg-[#22c55e] hover:bg-[#16a34a] text-white px-4 py-2 rounded-r-lg transition duration-300"
              >
                <i className="fas fa-arrow-right"></i>
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400">© {new Date().getFullYear()} SmartPark. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-white transition duration-300">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-white transition duration-300">Terms of Service</a>
            <a href="#" className="text-gray-400 hover:text-white transition duration-300">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  )
}