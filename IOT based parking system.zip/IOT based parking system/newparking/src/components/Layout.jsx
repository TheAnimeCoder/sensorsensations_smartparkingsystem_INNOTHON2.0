import React, { useState } from 'react';
import styled from 'styled-components';

const Layout = () => {
  const [occupiedSlots, setOccupiedSlots] = useState([]);

  const handleSlotClick = (slot) => {
    setOccupiedSlots((prev) => {
      if (prev.includes(slot)) {
        return prev.filter((s) => s !== slot); // Free the slot if already occupied
      } else {
        return [...prev, slot]; // Occupy the slot
      }
    });
  };

  const getArrowDirection = (slot) => {
    return occupiedSlots.includes(slot) ? '' : '→'; // Show arrow for available slots
  };

  return (
    <StyledLayout>
      <div className="side-section">
        <div className="entry">Entry</div>
        <div className="exit">Exit</div>
      </div>
      <div className="parking-area">
        <div className="car-parking">
          <h3>Car Parking</h3>
          {[...Array(5)].map((_, index) => {
            const slot = `Car ${index + 1}`;
            return (
              <div
                key={index}
                className={`parking-slot ${occupiedSlots.includes(slot) ? 'occupied' : 'available'}`}
                onClick={() => handleSlotClick(slot)}
                data-arrow={getArrowDirection(slot)}
              >
                {getArrowDirection(slot)} {slot}
              </div>
            );
          })}
        </div>
        <div className="bike-parking">
          <h3>Car Parking</h3>
          {[...Array(5)].map((_, index) => {
            const slot = `Car ${index + 1}`;
            return (
              <div
                key={index}
                className={`parking-slot ${occupiedSlots.includes(slot) ? 'occupied' : 'available'}`}
                onClick={() => handleSlotClick(slot)}
                data-arrow={getArrowDirection(slot)}
              >
                {getArrowDirection(slot)} {slot}
              </div>
            );
          })}
        </div>
      </div>
    </StyledLayout>
  );
};

const StyledLayout = styled.div`
  display: grid;
  grid-template-columns: 1fr 4fr; /* Increased the width of the parking area */
  gap: 10px;
  height: 100vh; /* Increased the overall height of the layout */
  padding: 20px;
  background-color: #f5f5f5;

  .side-section {
    display: flex;
    width: 50rem;
    flex-direction: column;
    justify-content: space-between;
    background-color: #e0e0e0;
    padding: 20px;
    border-radius: 10px;
  }

  .entry, .exit {
    background-color: blue;
    color: white;
    text-align: center;
    padding: 20px;
    height: 20%;
    width: 10%;
    font-size: 1rem;
    border-radius: 10px;
  }

  .exit {
    background-color: #f44336;
  }

  .parking-area {
    display: flex;
    width: 60%;
    flex-direction: column; /* Align car and bike parking side by side */
    justify-content: space-between; /* Add spacing between car and bike parking */
    gap: 20px;
    background-color: #e0e0e0;
    padding: 20px;
    border-radius: 10px;
  }

  .car-parking, .bike-parking {
    background-color: #ffffff;
    flex: 1; /* Ensure both car and bike parking take equal space */
    padding: 10px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }

  .parking-slot {
    position: relative;
    background-color: #4caf50; /* Green for available slots */
    color: white;
    width: 50%;
    height: 15%; /* Adjusted height for better alignment */
    text-align: center;
    padding: 10px;
    font-size: 1rem;
    border-radius: 5px;
    margin: 5px 0;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  .parking-slot.occupied {
    background-color: #f44336; /* Red for occupied slots */
  }

  .parking-slot.available::before {
    content: attr(data-arrow);
    position: absolute;
    top: 50%;
    left: -20px;
    transform: translateY(-50%);
    font-size: 1.2rem;
    color: #4caf50;
  }
`;

export default Layout;
