import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import axios from 'axios';
import SecondaryNavbar from './SecondaryNavbar';
import Login from './Login';

const UserPage = () => {
  const [userData, setUserData] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get('http://localhost:3000/users');
        const user = response.data[0]; // Assuming the first user is the logged-in user
        setUserData(user);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);


  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const userResponse = await axios.get('http://localhost:3000/users');
        const user = userResponse.data[0]; // Assuming the first user is the logged-in user
        setUser(user);
        const contactNumber = user.contactNumber; // Fetch contact number from user data

        const vehicleResponse = await axios.get('http://localhost:3000/vehicles');
        const allVehicles = vehicleResponse.data;
        const filteredVehicles = allVehicles.filter(vehicle => vehicle.contactNumber === contactNumber);
        setVehicles(filteredVehicles);
      } catch (error) {
        console.error('Error fetching vehicles:', error);
      }
    };

    fetchVehicles();
  }, []);

  if (!userData || !userData.isLoggedIn) {
    return <Login />;
  }

  return (
    <div>
      <SecondaryNavbar user={userData} />
      <StyledWrapper>
        <div className="home-container">
          <h1 className="title">Registered Vehicles</h1>
          <div className="vehicle-list">
            {vehicles.map((vehicle, index) => (
              <div key={index} className="vehicle-card">
                <p><strong>Owner:</strong> {vehicle.ownerName}</p>
                <p><strong>Vehicle Number:</strong> {vehicle.vehicleNumber}</p>
                <p><strong>Vehicle Type:</strong> {vehicle.vehicleType}</p>
                <p><strong>Engine/Chassis Number:</strong> {vehicle.engineOrChassisNumber}</p>
                {vehicle.qrCodePath && (
                  <div className="qr-code">
                    <h2>QR Code:</h2>
                    <img src={vehicle.qrCodePath} alt="Vehicle QR Code" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </StyledWrapper>
    </div>
  );
};

const StyledWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh; /* Changed from fixed height to min-height */
  background-color: #f5f5f5;

  .user-container {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    text-align: center;
    width: 300px;
    height: inherit;
  }

  .title {
    font-size: 24px;
    margin-bottom: 20px;
    color: #333;
  }

  .user-details {
    text-align: left;
    margin-bottom: 20px;
  }

  .edit-btn {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
  }

  .edit-btn:hover {
    background-color: #0056b3;
  }
  .home-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    width: 95rem;
    background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
    text-align: center;
    padding: 20px;
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }

  .title {
    font-size: 3rem;
    color: #2c3e50;
    margin-bottom: 20px;
    font-family: 'Poppins', sans-serif;
    font-weight: 700;
  }

  .description {
    font-size: 1.2rem;
    color: #666;
    margin-bottom: 30px;
  }

  .search-bar {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
  }

  .input {
    padding: 10px;
    font-size: 1rem;
    border: 1px solid #ddd;
    border-radius: 5px;
    width: 300px;
  }

  .search-button {
    padding: 10px 20px;
    font-size: 1rem;
    color: #fff;
    background-color: #007bff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
  }

  .search-button:hover {
    background-color: #0056b3;
  }

  .vehicle-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    justify-content: center;
  }

  .vehicle-card {
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 10px;
    background: #fff;
    text-align: left;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .vehicle-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 10px rgba(0, 0, 0, 0.15);
  }

  .vehicle-card p {
    margin: 10px 0;
    font-size: 1rem;
    color: #34495e;
    font-family: 'Roboto', sans-serif;
  }

  .qr-code {
    margin-top: 10px;
    text-align: center;
  }

  .qr-code h2 {
    font-size: 1.2rem;
    color: #2c3e50;
    margin-bottom: 10px;
  }

  .qr-code img {
    max-width: 100%;
    height: auto;
    border: 1px solid #ddd;
    border-radius: 5px;
  }

  .button-group {
    display: flex;
    gap: 15px;
  }

  .button {
    padding: 10px 20px;
    font-size: 1rem;
    color: #fff;
    background: #3498db;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    cursor: pointer;
    transition: background 0.3s ease;
  }

  .button:hover {
    background: #2980b9;
  }
`;


export default UserPage;