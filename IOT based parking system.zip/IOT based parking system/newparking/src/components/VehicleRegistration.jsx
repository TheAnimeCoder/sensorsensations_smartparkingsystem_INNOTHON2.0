import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import SecondaryNavbar from './SecondaryNavbar';
import fetchUserData from '../utils/fetchUserData';
import generateQRCode from '../utils/generateQRCode';

const VehicleRegistration = () => {
  const [inputType, setInputType] = useState('');
  const [formData, setFormData] = useState({
    ownerName: '',
    vehicleNumber: '',
    vehicleType: '',
    engineOrChassisNumber: '',
    contactNumber: '',
  });

  const [message, setMessage] = useState('');
  const [user, setUser] = useState(null);
  const [qrCodePath, setQrCodePath] = useState('');

  useEffect(() => {
    const getUserData = async () => {
      const users = await fetchUserData();
      setUser(users[0]); // Assuming the first user is the logged-in user
    };

    getUserData();
  }, []);

  const handleInputTypeChange = (e) => {
    setInputType(e.target.value);
    setFormData({ ...formData, engineOrChassisNumber: '' });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const qrPath = await generateQRCode(formData);
      const vehicleDataWithQR = { ...formData, qrCodePath: qrPath };

      const response = await fetch('http://localhost:3000/vehicles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(vehicleDataWithQR),
      });

      if (response.ok) {
        setMessage('Vehicle registered successfully!');
        setQrCodePath(qrPath);
        setFormData({
          ownerName: '',
          vehicleNumber: '',
          vehicleType: '',
          engineOrChassisNumber: '',
          contactNumber: '',
        });
        setInputType('');
      } else {
        setMessage('Failed to register vehicle. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      setMessage('An error occurred. Please try again later.');
    }
  };

  return (
    <div>
      {user && <SecondaryNavbar user={user} />}
      <StyledWrapper>
        <form className="form" onSubmit={handleSubmit}>
          <h1 className="title">Vehicle Registration</h1>
          <label>
            <input
              required
              type="text"
              name="ownerName"
              value={formData.ownerName}
              onChange={handleChange}
              className="input"
              placeholder="Owner Name"
            />
          </label>
          <label>
            <input
              required
              type="text"
              name="vehicleNumber"
              value={formData.vehicleNumber}
              onChange={handleChange}
              className="input"
              placeholder="Vehicle Number"
            />
          </label>
          <label>
            <select
              required
              name="vehicleType"
              value={formData.vehicleType}
              onChange={handleChange}
              className="input"
            >
              <option value="">Select Vehicle Type</option>
              <option value="Car">Car</option>
              <option value="Bike">Bike</option>
              <option value="Truck">Truck</option>
            </select>
          </label>
          <label>
            <select
              required
              value={inputType}
              onChange={handleInputTypeChange}
              className="input"
            >
              <option value="">Select Input Type</option>
              <option value="engine">Engine Number</option>
              <option value="chassis">Chassis Number</option>
            </select>
          </label>
          {inputType === 'engine' && (
            <label>
              <input
                required
                type="text"
                name="engineOrChassisNumber"
                value={formData.engineOrChassisNumber}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^[A-Za-z0-9]*$/.test(value) && value.length <= 17) {
                    handleChange(e);
                  }
                }}
                className="input"
                placeholder="Engine Number (11-17 alphanumeric characters)"
              />
            </label>
          )}
          {inputType === 'chassis' && (
            <label>
              <input
                required
                type="text"
                name="engineOrChassisNumber"
                value={formData.engineOrChassisNumber}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^[A-Za-z0-9]*$/.test(value) && value.length <= 17) {
                    handleChange(e);
                  }
                }}
                onBlur={(e) => {
                  const value = e.target.value;
                  if (value.length !== 17) {
                    setMessage('Chassis Number must be exactly 17 characters long.');
                  } else {
                    setMessage('');
                  }
                }}
                className="input"
                placeholder="Chassis Number (exactly 17 characters)"
              />
            </label>
          )}
          <label>
            <input
              required
              type="text"
              name="contactNumber"
              value={formData.contactNumber || ''}
              onChange={handleChange}
              className="input"
              placeholder="Contact Number"
            />
          </label>
          <button className="submit">Register</button>
          {message && <p className="message">{message}</p>}
          {qrCodePath && (
            <div className="qr-code">
              <h2>Generated QR Code:</h2>
              <img src={qrCodePath} alt="Vehicle QR Code" />
            </div>
          )}
        </form>
      </StyledWrapper>
    </div>
  );
};

const StyledWrapper = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;

  .form {
    display: flex;
    flex-direction: column;
    gap: 15px;
    background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  }

  .title {
    font-size: 2.5rem;
    color: #2c3e50;
    margin-bottom: 20px;
    font-family: 'Poppins', sans-serif;
    font-weight: 700;
  }

  .input {
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 10px;
    font-size: 1rem;
    font-family: 'Roboto', sans-serif;
    color: black; /* Set input text color to black */
  }

  .submit {
    padding: 12px;
    font-size: 1rem;
    color: #fff;
    background: #3498db;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    transition: background 0.3s ease;
  }

  .submit:hover {
    background: #2980b9;
  }

  .message {
    color: green;
    font-size: 0.9rem;
    margin-top: 10px;
  }

  .qr-code {
    margin-top: 20px;
    text-align: center;

    h2 {
      font-size: 1.2rem;
      color: #2c3e50;
      margin-bottom: 10px;
    }

    img {
      max-width: 100%;
      height: auto;
      border: 1px solid #ddd;
      border-radius: 10px;
    }
  }
`;

export default VehicleRegistration;