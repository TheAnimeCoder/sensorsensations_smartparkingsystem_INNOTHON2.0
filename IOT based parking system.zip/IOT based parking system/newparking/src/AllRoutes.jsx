import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Home from './Home';
import UserPage from './components/UserPage';
import VehicleRegistration from './components/VehicleRegistration';
import SecondaryNavbar from './components/SecondaryNavbar';
import PrivateRoute from './components/PrivateRoute';
import Wallet from './components/Wallet';
import Layout from './components/Layout';

const AllRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/user" element={<UserPage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/vehicle-registration" element={<VehicleRegistration />} />
      <Route path="/secondary-navbar" element={<SecondaryNavbar user={{ firstname: 'John', lastname: 'Doe', email: 'john.doe@example.com' }} />} />
      <Route path="/wallet" element={<PrivateRoute><Wallet /></PrivateRoute>} />
      <Route path="/layout" element={<Layout />} />
    </Routes>
  );
};

export default AllRoutes;
