import { useState } from 'react'

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })
  
  const [formStatus, setFormStatus] = useState(null)

  const handleChange = (e) => {
    const { id, value } = e.target
    setFormData(prev => ({ ...prev, [id]: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    
    // Form validation
    if (!formData.name || !formData.email || !formData.subject || !formData.message) {
      setFormStatus({
        type: 'error',
        message: 'Please fill in all fields'
      })
      return
    }
    
    // For demo purposes only - simulate API call
    setFormStatus({
      type: 'success',
      message: 'Thank you for your message. We will get back to you shortly!'
    })
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    })
  }

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-[#1d74e9] mb-4">Contact & Support</h2>
            <p className="text-lg text-gray-600 mb-8">Have questions about our smart parking system? Get in touch with our dedicated support team.</p>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="flex-shrink-0 h-10 w-10 bg-[#1d74e9]/10 rounded-full flex items-center justify-center">
                  <i className="fas fa-map-marker-alt text-[#1d74e9]"></i>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-800">Our Location</h3>
                  <p className="text-gray-600">123 Tech Park, Innovation District<br/>Smartville, CA 94025</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 h-10 w-10 bg-[#1d74e9]/10 rounded-full flex items-center justify-center">
                  <i className="fas fa-phone-alt text-[#1d74e9]"></i>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-800">Call Us</h3>
                  <p className="text-gray-600">+1 (800) SMART-PARK<br/>Support: 24/7 Available</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0 h-10 w-10 bg-[#1d74e9]/10 rounded-full flex items-center justify-center">
                  <i className="fas fa-envelope text-[#1d74e9]"></i>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-semibold text-gray-800">Email Us</h3>
                  <p className="text-gray-600">info@smartpark.io<br/>support@smartpark.io</p>
                </div>
              </div>
            </div>
            
            <div className="mt-8 flex space-x-4">
              <a href="#" className="h-12 w-12 bg-[#1877F2] hover:bg-[#1877F2]/80 rounded-full flex items-center justify-center text-white transition duration-300">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="h-12 w-12 bg-[#1DA1F2] hover:bg-[#1DA1F2]/80 rounded-full flex items-center justify-center text-white transition duration-300">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="h-12 w-12 bg-[#0A66C2] hover:bg-[#0A66C2]/80 rounded-full flex items-center justify-center text-white transition duration-300">
                <i className="fab fa-linkedin-in"></i>
              </a>
              <a href="#" className="h-12 w-12 bg-[#0088cc] hover:bg-[#0088cc]/80 rounded-full flex items-center justify-center text-white transition duration-300">
                <i className="fab fa-telegram"></i>
              </a>
            </div>
          </div>
          
          <div className="bg-gray-50 rounded-xl shadow-lg p-8">
            <h3 className="text-2xl font-semibold text-[#1d74e9] mb-6">Get In Touch</h3>
            
            {formStatus && (
              <div className={`p-4 mb-6 rounded-lg ${formStatus.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                {formStatus.message}
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                  <input 
                    type="text" 
                    id="name" 
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#1d74e9] focus:border-transparent" 
                    placeholder="John Doe" 
                    value={formData.name}
                    onChange={handleChange}
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                  <input 
                    type="email" 
                    id="email" 
                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#1d74e9] focus:border-transparent" 
                    placeholder="john@example.com" 
                    value={formData.email}
                    onChange={handleChange}
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                <input 
                  type="text" 
                  id="subject" 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#1d74e9] focus:border-transparent" 
                  placeholder="How can we help you?" 
                  value={formData.subject}
                  onChange={handleChange}
                />
              </div>
              
              <div className="mb-6">
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                <textarea 
                  id="message" 
                  rows={4} 
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-[#1d74e9] focus:border-transparent" 
                  placeholder="Type your message here..."
                  value={formData.message}
                  onChange={handleChange}
                ></textarea>
              </div>
              
              <button type="submit" className="w-full bg-[#1d74e9] hover:bg-[#1259b8] text-white font-semibold py-3 px-6 rounded-lg transition duration-300">
                <i className="fas fa-paper-plane mr-2"></i> Send Message
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}