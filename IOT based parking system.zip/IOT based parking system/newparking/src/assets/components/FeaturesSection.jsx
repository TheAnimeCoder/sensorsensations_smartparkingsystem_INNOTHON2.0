export default function FeaturesSection() {
  const features = [
    {
      icon: "fas fa-qrcode",
      title: "QR Entry & Exit",
      description: "Contactless entry and exit with secure QR code technology. No tickets, no hassle."
    },
    {
      icon: "fas fa-lightbulb",
      title: "LED Navigation",
      description: "Smart LED indicators guide you directly to your designated parking spot."
    },
    {
      icon: "fas fa-wifi",
      title: "Live Slot Status",
      description: "Real-time parking availability updates on your mobile device or dashboard."
    },
    {
      icon: "fas fa-microphone-alt",
      title: "Voice Assistant",
      description: "Integrated voice commands for hands-free assistance and navigation."
    }
  ]

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-[#1d74e9] mb-4">Smart Features</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">Our IoT-enabled parking system combines cutting-edge technology with user-friendly design to make parking hassle-free.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl shadow-lg p-6 transform hover:-translate-y-2 transition duration-300"
            >
              <div className="flex items-center justify-center h-16 w-16 bg-[#1d74e9]/10 rounded-full mb-6 mx-auto">
                <i className={`${feature.icon} text-[#1d74e9] text-2xl`}></i>
              </div>
              <h3 className="text-xl font-semibold text-[#1d74e9] text-center mb-3">{feature.title}</h3>
              <p className="text-gray-600 text-center">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}