# Parking Management System

This project is a Parking Management System built using React and Vite. It allows users to register vehicles, generate QR codes for vehicle data, and view registered vehicles with their associated QR codes.

## Features

- **User Authentication**: Users can log in to access their registered vehicles.
- **Vehicle Registration**: Users can register their vehicles by providing details such as driver name, vehicle number, type, engine/chassis number, and contact number.
- **QR Code Generation**: Automatically generates a QR code for each registered vehicle and stores it in the database.
- **Vehicle Management**: Displays a list of registered vehicles with their details and QR codes.
- **Responsive Design**: The application is designed to work seamlessly on various devices.

## Technologies Used

- **React**: Frontend library for building user interfaces.
- **Vite**: Build tool for fast development.
- **Styled Components**: For styling React components.
- **Axios**: For making HTTP requests.
- **JSON Server**: Used as a mock backend to store user and vehicle data.
- **QRCode**: Library for generating QR codes.

## Project Structure

```
src/
  components/
    UserPage.jsx
    VehicleRegistration.jsx
    ...other components
  utils/
    fetchUserData.js
    generateQRCode.js
  App.jsx
  main.jsx
  index.css
```

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone <repository-url>
   ```

2. Navigate to the project directory:
   ```bash
   cd newparking
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Start the development server:
   ```bash
   npm run dev
   ```

5. Start the JSON server for the mock backend:
   ```bash
   npx json-server --watch db.json --port 3000
   ```

6. Open the application in your browser at `http://localhost:5173`.

## API Endpoints

- **Users**: `http://localhost:3000/users`
- **Vehicles**: `http://localhost:3000/vehicles`

## Future Enhancements

- Add role-based access control.
- Implement real-time updates for vehicle data.
- Integrate with a real backend service.

## License

This project is licensed under the MIT License.
